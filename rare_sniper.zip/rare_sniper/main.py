#!/usr/bin/env python3
"""sniper by 385 tepes & krypt - ponto de entrada.  python3 main.py  (abre o menu)"""
from sniper.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
