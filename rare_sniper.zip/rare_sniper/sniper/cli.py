"""Linha de comando. Sem argumentos abre o menu."""
from __future__ import annotations

import argparse
import asyncio
import sys

from . import CREDITS, __version__
from .core.candidates import WORDLIST_URLS, download_wordlists
from .core import custom_api as ca
from .core.config import Settings, load_dotenv, load_settings
from .core.platform import REGISTRY, missing_env
from .platforms import LOAD_ERRORS, load_all
from .session import setup_logging, start, test_notify


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="main.py",
        description=f"sniper by {CREDITS} v{__version__} - sem argumentos abre o menu.",
    )
    p.add_argument("--run", action="store_true", help="inicia direto, sem menu (usa a config salva + flags)")
    p.add_argument("-p", "--platforms", nargs="+", choices=sorted(REGISTRY))
    p.add_argument("--min-len", type=int)
    p.add_argument("--max-len", type=int)
    p.add_argument("--digits", action="store_true", help="inclui 0-9 no gerador")
    p.add_argument("--chars", help="caracteres extras no gerador (ex.: _.)")
    p.add_argument("--wordlist", nargs="+", help="arquivos de dicionario (padrao: wordlists/en.txt, pt.txt)")
    p.add_argument("--rate", type=float, help="req/s por plataforma (padrao: conservador por plataforma)")
    p.add_argument("--concurrency", type=int, help="workers por plataforma")
    p.add_argument("--no-notify", action="store_true", help="nao envia avisos (so tela + hits.txt)")
    p.add_argument("--plain", action="store_true", help="sem painel: log simples (para tmux/servidor/redirecionar)")
    p.add_argument("--test-notify", action="store_true", help="envia mensagem de teste no webhook e sai")
    p.add_argument("--download-wordlists", action="store_true", help="baixa dicionarios completos EN/PT e sai")
    p.add_argument("--en-url", default=WORDLIST_URLS["en"])
    p.add_argument("--pt-url", default=WORDLIST_URLS["pt"])
    p.add_argument("--list-platforms", action="store_true", help="lista os plugins carregados e sai")
    p.add_argument("--list-apis", action="store_true", help="lista as 5 APIs customizaveis (apis.json) e sai")
    p.add_argument("--api", nargs="+", metavar=("SLOT", "VALOR"),
                   help="roda uma API customizavel: SLOT (1-5 ou nome) e o VALOR ({input}), ex.: --api ip_info 8.8.8.8")
    p.add_argument("-v", "--verbose", action="store_true")
    return p


def apply_overrides(s: Settings, a: argparse.Namespace) -> Settings:
    if a.platforms:
        s.platforms = a.platforms
    if a.min_len is not None:
        s.min_len = a.min_len
    if a.max_len is not None:
        s.max_len = a.max_len
    if a.digits:
        s.digits = True
    if a.chars is not None:
        s.extra_chars = a.chars
    if a.wordlist:
        s.wordlists = a.wordlist
    if a.rate is not None:
        s.rate = a.rate
    if a.concurrency is not None:
        s.concurrency = a.concurrency
    if a.no_notify:
        s.notify = False
    return s.validate()


def print_platforms() -> None:
    print(f"Plataformas carregadas ({len(REGISTRY)}):")
    for n in sorted(REGISTRY):
        cls = REGISTRY[n]
        miss = missing_env(cls)
        extra = f"  [falta: {', '.join(miss)}]" if miss else ""
        print(f"  {n:<10} {cls.display:<10} {cls.default_rate:>4} req/s  {cls.description}{extra}")
    for mod, err in LOAD_ERRORS.items():
        print(f"  ERRO no plugin {mod}: {err}")


def print_apis() -> None:
    print(f"APIs customizaveis ({ca.SLOT_COUNT} slots, arquivo apis.json):")
    for sl in ca.load_slots():
        state = "ligada" if sl.enabled else "desligada"
        label = sl.name or "(livre)"
        print(f"  {sl.slot}) {label:<14} {state:<9} {sl.mode:<8} {sl.method:<5} {ca.safe_url(sl.url) or '-'}")
        if sl.enabled and (errs := ca.validate(sl)):
            print(f"       ! {'; '.join(errs)}")


def cmd_api(spec: list[str]) -> int:
    slots = ca.load_slots()
    slot = ca.find_slot(slots, spec[0])
    if slot is None:
        print(f"API '{spec[0]}' nao encontrada (use --list-apis).")
        return 2
    errs = ca.validate(slot)
    if errs:
        print("Configuracao invalida: " + "; ".join(errs))
        return 2
    value = " ".join(spec[1:])
    if slot.mode == "lookup":
        res = asyncio.run(ca.run_lookup(slot, value))
        print(ca.format_lookup(slot, res))
        return 0 if res.ok else 1
    check = asyncio.run(ca.run_check(slot, value))
    print(ca.format_check(check))
    return 0 if check.error is None else 1


def main(argv: list[str] | None = None) -> int:
    load_dotenv()
    load_all()  # descobre os plugins em sniper/platforms/
    args = build_parser().parse_args(argv)
    settings = apply_overrides(load_settings(), args)

    if args.list_platforms:
        print_platforms()
        return 0
    if args.list_apis:
        print_apis()
        return 0
    setup_logging(args.verbose)
    if args.api:
        return cmd_api(args.api)
    if args.download_wordlists:
        asyncio.run(download_wordlists({"en": args.en_url, "pt": args.pt_url}))
        return 0
    if args.test_notify:
        ok, msg = asyncio.run(test_notify())
        print(msg)
        return 0 if ok else 1
    if args.run:
        return start(settings, use_dashboard=sys.stdout.isatty() and not args.plain, verbose=args.verbose)

    from .ui.menu import run_menu
    try:
        run_menu(settings, verbose=args.verbose)
    except KeyboardInterrupt:
        print(f"\nAté mais — sniper by {CREDITS}")
    return 0
