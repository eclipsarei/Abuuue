from __future__ import annotations

"""Caminhos do projeto: tudo e relativo a pasta do projeto, nao ao diretorio atual."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def project_path(p: str | Path) -> Path:
    p = Path(p)
    return p if p.is_absolute() else ROOT / p
