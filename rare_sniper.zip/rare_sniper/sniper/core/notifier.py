"""Aviso via webhook do Discord (sem bot e sem token de conta)."""
from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import re

import aiohttp

from .http import USER_AGENT, HttpClient, RateLimiter
from .types import Hit, RetriesExhausted

log = logging.getLogger(__name__)

WEBHOOK_RE = re.compile(
    r"https://(?:(?:ptb|canary)\.)?discord(?:app)?\.com/api/(?:v\d+/)?webhooks/\d+/[\w-]+"
)
WEBHOOK_NAME = "Sniper • 385 tepes & krypt"  # o Discord proibe "discord"/"clyde" no nome


class DiscordWebhookNotifier:
    MIN_INTERVAL = 1.0  # limite do Discord: ~5 requests / 2s por webhook
    BATCH_WINDOW = 2.0  # espera um pouco para juntar achados em 1 mensagem
    MAX_BATCH = 8  # mantem a mensagem abaixo do limite de 2000 caracteres

    def __init__(self, webhook_url: str, ping_user_id: str | None = None):
        self.url = webhook_url
        self.ping_user_id = ping_user_id
        self.queue: asyncio.Queue[Hit] = asyncio.Queue()
        self.sent = 0  # mensagens entregues
        self.failed = 0
        self._session: aiohttp.ClientSession | None = None
        self._http: HttpClient | None = None
        self._task: asyncio.Task | None = None

    async def __aenter__(self) -> "DiscordWebhookNotifier":
        self._session = aiohttp.ClientSession(headers={"User-Agent": USER_AGENT}, trust_env=True)
        self._http = HttpClient(
            self._session, RateLimiter(1 / self.MIN_INTERVAL),
            max_retries=8, base_delay=2.0, max_delay=120.0,
        )
        self._task = asyncio.create_task(self._run())
        return self

    async def __aexit__(self, *exc) -> None:
        try:
            await asyncio.wait_for(self.queue.join(), timeout=90)
        except asyncio.TimeoutError:
            log.error("Discord: %d aviso(s) nao enviados - veja hits.txt", self.queue.qsize())
        assert self._task and self._session
        self._task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await self._task
        await self._session.close()

    def notify(self, hit: Hit) -> None:
        self.queue.put_nowait(hit)

    def format(self, hits: list[Hit]) -> str:
        lines = []
        if self.ping_user_id:
            lines.append(f"<@{self.ping_user_id}>")
        if len(hits) == 1:
            lines += ["🎯 **Nome raro disponível!**", ""]
        else:
            lines += [f"🎯 **{len(hits)} nomes raros disponíveis!**", ""]
        for h in hits:
            line = f"**{h.platform}** · `{h.name}` · {len(h.name)} caracteres · {h.source}"
            if not h.confirmed:
                line += " ⚠️ não reconfirmado"
            if h.url:
                line += f" · <{h.url}>"  # <> evita o preview gigante do link
            lines.append(line)
        return "\n".join(lines)

    async def _run(self) -> None:
        while True:
            batch = [await self.queue.get()]
            await asyncio.sleep(self.BATCH_WINDOW)
            while len(batch) < self.MAX_BATCH and not self.queue.empty():
                batch.append(self.queue.get_nowait())
            try:
                await self.send_text(self.format(batch))
            except Exception as exc:  # nunca derruba o notificador
                self.failed += 1
                log.error("Discord: falha inesperada ao avisar (%s)", type(exc).__name__)
            finally:
                for _ in batch:
                    self.queue.task_done()

    async def send_text(self, text: str) -> bool:
        assert self._http
        payload = {
            "content": text[:2000],
            "username": WEBHOOK_NAME,
            # so marca quem voce configurou; nunca @everyone/@here
            "allowed_mentions": {"users": [self.ping_user_id]} if self.ping_user_id else {"parse": []},
        }
        try:
            resp = await self._http.request("POST", self.url, json=payload)
        except RetriesExhausted as exc:
            self.failed += 1
            log.error("Discord: retries esgotados (%s)", exc)
            return False
        if resp.status in (200, 204):
            self.sent += 1
            return True
        self.failed += 1
        try:
            desc = json.loads(resp.text).get("message", resp.text[:200])
        except (ValueError, AttributeError):
            desc = resp.text[:200]
        log.error("Webhook do Discord recusou (HTTP %s): %s", resp.status, desc)
        if resp.status in (401, 404):
            log.error("-> webhook invalido ou apagado. Gere outro e atualize DISCORD_WEBHOOK_URL.")
        elif resp.status == 400:
            log.error("-> requisicao recusada; confira DISCORD_PING_USER_ID (so numeros).")
        return False


def webhook_configured() -> bool:
    return bool(WEBHOOK_RE.fullmatch(os.environ.get("DISCORD_WEBHOOK_URL", "").strip()))


def build_notifier() -> tuple[DiscordWebhookNotifier | None, str | None]:
    """(notificador, None) se a configuracao estiver ok; (None, mensagem de erro) senao."""
    url = os.environ.get("DISCORD_WEBHOOK_URL", "").strip()
    if not WEBHOOK_RE.fullmatch(url):
        return None, ("DISCORD_WEBHOOK_URL ausente ou invalida no .env "
                      "(Canal > Editar canal > Integracoes > Webhooks > Copiar URL).")
    ping = os.environ.get("DISCORD_PING_USER_ID", "").strip() or None
    if ping and not ping.isdigit():
        return None, "DISCORD_PING_USER_ID deve conter so numeros."
    return DiscordWebhookNotifier(url, ping), None
