"""Rate limiter adaptativo + cliente HTTP com retry/backoff (429, 5xx e 529)."""
from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from urllib.parse import urlsplit

import aiohttp

from .types import Response, RetriesExhausted

log = logging.getLogger(__name__)

USER_AGENT = "Mozilla/5.0 (compatible; rare-name-checker/2.0)"
# 529 = "overloaded" (nao padrao, usado por varias APIs/CDNs). 429 = rate limit.
RETRYABLE = {429, 500, 502, 503, 504, 529}


class RateLimiter:
    """Intervalo minimo entre requests, com cooldown global e auto-ajuste."""

    def __init__(self, rate_per_sec: float):
        self.base_interval = 1.0 / max(rate_per_sec, 0.01)
        self.interval = self.base_interval
        self.max_interval = self.base_interval * 20
        self._next = 0.0
        self._cooldown_until = 0.0
        self._lock = asyncio.Lock()

    async def wait(self) -> None:
        while True:
            async with self._lock:
                now = time.monotonic()
                if now < self._cooldown_until:
                    delay = self._cooldown_until - now
                elif now < self._next:
                    delay = self._next - now
                else:
                    self._next = now + self.interval
                    return
            await asyncio.sleep(delay)

    def penalize(self, seconds: float) -> None:
        """Pausa todos os workers que usam este limiter."""
        self._cooldown_until = max(self._cooldown_until, time.monotonic() + seconds)

    def cooldown_remaining(self) -> float:
        return max(0.0, self._cooldown_until - time.monotonic())

    def slow_down(self) -> None:
        self.interval = min(self.interval * 1.5, self.max_interval)

    def speed_up(self) -> None:
        self.interval = max(self.base_interval, self.interval * 0.98)


def _parse_retry_after(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return max(0.0, float(value))
    except ValueError:
        return None


def _retry_after_from_body(text: str) -> float | None:
    """O Discord devolve {"message": ..., "retry_after": 0.5, "global": false} no 429."""
    try:
        return float(json.loads(text)["retry_after"])
    except (ValueError, KeyError, TypeError):
        return None


class HttpClient:
    def __init__(
        self,
        session: aiohttp.ClientSession,
        limiter: RateLimiter,
        max_retries: int = 6,
        base_delay: float = 3.0,
        max_delay: float = 180.0,
    ):
        self.session = session
        self.limiter = limiter
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.timeout = aiohttp.ClientTimeout(total=15)

    def _pace_from_headers(self, h: dict[str, str]) -> None:
        """Se a API avisa que o limite acabou (remaining=0), pausa ate o reset ANTES de levar 429.
        Cobre Discord (x-ratelimit-reset-after / epoch), Roblox (segundos) e X (x-rate-limit-*, epoch)."""
        remaining = h.get("x-ratelimit-remaining") or h.get("x-rate-limit-remaining")
        if remaining is None:
            return
        try:
            if int(float(remaining)) > 0:
                return
            reset_after = h.get("x-ratelimit-reset-after")
            if reset_after:
                wait = float(reset_after)
            else:
                reset = h.get("x-ratelimit-reset") or h.get("x-rate-limit-reset")
                if not reset:
                    return
                value = float(reset)
                wait = value - time.time() if value > 1e9 else value  # epoch x segundos
        except ValueError:
            return
        if 0 < wait <= 900:
            self.limiter.penalize(wait + 0.5)
            log.debug("limite esgotado - pausa preventiva de %.1fs", wait)

    async def request(self, method: str, url: str, **kwargs) -> Response:
        host = urlsplit(url).netloc  # so o host nos logs (a URL do webhook contem o segredo)
        reason = "?"
        for attempt in range(self.max_retries + 1):
            await self.limiter.wait()
            retry_after = None
            try:
                async with self.session.request(
                    method, url, timeout=self.timeout, **kwargs
                ) as r:
                    body = await r.text()
                    resp = Response(
                        r.status, body, {k.lower(): v for k, v in r.headers.items()}
                    )
                self._pace_from_headers(resp.headers)
                if resp.status not in RETRYABLE:
                    self.limiter.speed_up()
                    return resp
                reason = f"HTTP {resp.status}"
                retry_after = _parse_retry_after(resp.headers.get("retry-after"))
                if retry_after is None:
                    retry_after = _retry_after_from_body(resp.text)
            except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
                reason = type(exc).__name__

            delay = min(self.max_delay, self.base_delay * (2**attempt))
            delay *= random.uniform(0.7, 1.3)  # jitter
            if retry_after:
                delay = max(delay, retry_after + 1)
            self.limiter.slow_down()
            self.limiter.penalize(delay)
            log.warning(
                "%s em %s - backoff %.1fs (tentativa %d/%d, intervalo agora %.2fs)",
                reason, host, delay, attempt + 1, self.max_retries + 1, self.limiter.interval,
            )
        raise RetriesExhausted(reason)
