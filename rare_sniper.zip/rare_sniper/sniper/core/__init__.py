"""Nucleo: HTTP com backoff, estado, dicionarios, notificador e motor."""
