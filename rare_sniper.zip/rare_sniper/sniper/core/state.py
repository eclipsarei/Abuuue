"""Estado persistente: retoma de onde parou e guarda os achados."""
from __future__ import annotations

import time
from pathlib import Path

from .types import Status


class State:
    def __init__(self, path: Path, hits_path: Path):
        self.done: set[tuple[str, str]] = set()
        if path.is_file():
            for line in path.read_text(encoding="utf-8").splitlines():
                parts = line.split("\t")
                if len(parts) == 3 and parts[2] != Status.UNKNOWN.value:
                    self.done.add((parts[0], parts[1]))
        self._state_fh = path.open("a", encoding="utf-8")
        self._hits_fh = hits_path.open("a", encoding="utf-8")

    def seen(self, platform: str, name: str) -> bool:
        return (platform, name) in self.done

    def record(self, platform: str, name: str, status: Status) -> None:
        if status is not Status.UNKNOWN:
            self.done.add((platform, name))
        self._state_fh.write(f"{platform}\t{name}\t{status.value}\n")
        self._state_fh.flush()

    def hit(self, platform: str, name: str, confirmed: bool) -> None:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        flag = "confirmado" if confirmed else "nao-reconfirmado"
        self._hits_fh.write(f"{stamp}\t{platform}\t{name}\t{flag}\n")
        self._hits_fh.flush()

    def close(self) -> None:
        self._state_fh.close()
        self._hits_fh.close()
