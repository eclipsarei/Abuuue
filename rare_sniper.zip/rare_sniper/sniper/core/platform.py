"""Contrato dos plugins de plataforma + registro.

Para criar uma plataforma nova: copie sniper/platforms/_template.py para
sniper/platforms/<nome>.py, tire o '_' da decoracao @register e implemente check().
O carregador (sniper/platforms/__init__.py) descobre o arquivo sozinho.
"""
from __future__ import annotations

import os
import re
from abc import ABC, abstractmethod

from .http import HttpClient
from .types import Status

REGISTRY: dict[str, type["Platform"]] = {}


def register(cls: type["Platform"]) -> type["Platform"]:
    if not cls.name:
        raise ValueError(f"{cls.__name__}: defina o atributo 'name'")
    if cls.name in REGISTRY and REGISTRY[cls.name] is not cls:
        raise ValueError(f"plataforma duplicada: {cls.name}")
    REGISTRY[cls.name] = cls
    return cls


class Platform(ABC):
    name: str = ""  # id curto, usado na CLI e no estado (ex.: "discord")
    display: str = ""  # nome bonito nas mensagens (ex.: "Discord")
    description: str = ""  # uma linha, mostrada no menu
    pattern: re.Pattern = re.compile(r"^$")  # username valido (usado com fullmatch)
    default_rate: float = 1.0  # requests/segundo (conservador)
    requires_env: tuple[str, ...] = ()  # variaveis de ambiente obrigatorias (ex.: chaves de API)
    batch_size: int = 1  # >1 = a plataforma consulta varios nomes por requisicao (implemente check_many)

    def __init__(self, http: HttpClient):
        self.http = http

    async def setup(self) -> None:
        """Opcional: aquecimento antes de comecar (cookies, tokens de guest, etc.)."""

    def is_valid(self, name: str) -> bool:
        return bool(self.pattern.fullmatch(name)) and self.extra_rules(name)

    def extra_rules(self, name: str) -> bool:
        """Regras que o regex nao cobre (ex.: sem '..', sem '_' no fim)."""
        return True

    def profile_url(self, name: str) -> str | None:
        """Link do perfil mostrado no aviso (ou None)."""
        return None

    @abstractmethod
    async def check(self, name: str) -> Status:
        """Retorna AVAILABLE / TAKEN / INVALID / UNKNOWN."""

    async def check_many(self, names: list[str]) -> dict[str, Status]:
        """Consulta em lote. Padrao: um por um. Plataformas com API em lote sobrescrevem
        (e definem batch_size) - o motor ja agrupa os candidatos."""
        return {n: await self.check(n) for n in names}


def missing_env(cls: type[Platform]) -> list[str]:
    return [v for v in cls.requires_env if not os.environ.get(v)]
