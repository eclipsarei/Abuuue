"""Configuracoes persistentes (sniper_config.json) e .env."""
from __future__ import annotations

import json
import os
import re
import string
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path

from ..paths import ROOT

CONFIG_PATH = ROOT / "sniper_config.json"


@dataclass
class Settings:
    platforms: list[str] = field(default_factory=list)  # vazio = todas
    min_len: int = 2
    max_len: int = 4
    digits: bool = False
    extra_chars: str = ""  # ex.: "_." (gerador tambem usa esses caracteres)
    concurrency: int = 2
    rate: float | None = None  # req/s; None = padrao de cada plataforma
    wordlists: list[str] = field(default_factory=list)  # vazio = padrao
    notify: bool = True
    state_file: str = "sniper_state.tsv"
    hits_file: str = "hits.txt"

    @property
    def charset(self) -> str:
        chars = string.ascii_lowercase + (string.digits if self.digits else "") + self.extra_chars
        return "".join(dict.fromkeys(chars))

    def validate(self) -> "Settings":
        self.min_len = max(1, min(int(self.min_len), 12))
        self.max_len = max(self.min_len, min(int(self.max_len), 12))
        self.concurrency = max(1, min(int(self.concurrency), 10))
        self.extra_chars = re.sub(r"[^a-z0-9_.]", "", str(self.extra_chars).lower())
        if self.rate is not None:
            self.rate = max(0.01, float(self.rate))
        return self


def load_settings(path: Path = CONFIG_PATH) -> Settings:
    settings = Settings()
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            known = {f.name for f in fields(Settings)}
            for key, value in data.items():
                if key in known:
                    setattr(settings, key, value)
        except (ValueError, OSError):
            pass  # config corrompida: volta ao padrao
    return settings.validate()


def save_settings(settings: Settings, path: Path = CONFIG_PATH) -> None:
    path.write_text(json.dumps(asdict(settings), indent=2, ensure_ascii=False), encoding="utf-8")


def load_dotenv(path: Path = ROOT / ".env") -> None:
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))
