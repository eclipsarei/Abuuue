"""APIs customizaveis: 5 entradas definidas em apis.json (sem programar).

Cada slot e uma requisicao HTTP configuravel, em um de dois modos:
  "lookup"   - consulta manual (menu ou `--api SLOT VALOR`): ex. informacoes de um IP.
               Mostra os campos JSON listados em "show" (ou os 40 primeiros).
  "platform" - vira uma plataforma do sniper (checa disponibilidade de username) com as
               "rules" que voce define; aparece no menu/CLI como qualquer outra.

Placeholders (URL, headers e body):
  {input} / {name}   o valor consultado (na URL vai com URL-encode)
  {env:NOME}         valor da variavel de ambiente NOME (.env) - use para chaves de API
Regras ("rules": {"available":[...], "taken":[...], "invalid":[...]}) - cada regra e um objeto
cujas condicoes valem juntas (E); basta UMA regra da lista bater (OU). Ordem: invalid, taken, available.
  {"status": 404}  {"status": [200,204]}  {"contains": "texto"}  {"not_contains": "x"}
  {"regex": "..."}  {"json": "a.b.0.c", "equals": false}  {"json": "x", "exists": true}
Atalhos: 404 vira {"status":404}; "texto" vira {"contains":"texto"}.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from dataclasses import asdict, dataclass, field, fields
from typing import Any, Iterator
from urllib.parse import quote, urlsplit

import aiohttp

from ..paths import ROOT
from .http import USER_AGENT, HttpClient, RateLimiter
from .types import RetriesExhausted, Status

log = logging.getLogger(__name__)

SLOT_COUNT = 5
APIS_PATH = ROOT / "apis.json"
METHODS = ("GET", "POST", "PUT", "PATCH", "DELETE")
MODES = ("lookup", "platform")
_PLACEHOLDER = re.compile(r"\{(input|name|env:[A-Za-z_][A-Za-z0-9_]*)\}")
_HELP = ("5 APIs customizaveis. Edite aqui ou pelo menu (opcao 7). Placeholders: {input} {name} {env:VAR}. "
         "Modos: lookup (consulta manual) | platform (checa username). Veja o topo de sniper/core/custom_api.py.")


class ApiError(Exception):
    pass


@dataclass
class ApiSlot:
    slot: int = 0
    enabled: bool = False
    name: str = ""
    description: str = ""
    mode: str = "lookup"
    method: str = "GET"
    url: str = ""
    headers: dict = field(default_factory=dict)
    body: Any = None
    rate: float = 1.0  # req/s
    show: list = field(default_factory=list)  # lookup: campos JSON mostrados
    run_on_start: bool = False  # lookup: roda ao iniciar o sniper e loga o resumo (ex.: meu IP)
    pattern: str = "[a-z0-9_]{3,20}"  # platform: username valido (regex, fullmatch)
    rules: dict = field(default_factory=dict)  # platform

    @property
    def slug(self) -> str:
        return re.sub(r"[^a-z0-9_]+", "_", self.name.lower()).strip("_")

    def env_vars(self) -> list[str]:
        blob = json.dumps([self.url, self.headers, self.body], ensure_ascii=False)
        return sorted({m[4:] for m in _PLACEHOLDER.findall(blob) if m.startswith("env:")})


def default_slots() -> list[ApiSlot]:
    ip_fields = ["query", "country", "regionName", "city", "isp", "org", "as", "proxy", "hosting"]
    return [
        ApiSlot(1, True, "meu_ip", "Seu IP público (confira VPN/proxy)", "lookup", "GET",
                "https://api.ipify.org?format=json", show=["ip"], rate=0.5),
        ApiSlot(2, True, "ip_info", "Geolocalização/ISP de um IP (ip-api.com, grátis, 45 req/min, só HTTP)",
                "lookup", "GET",
                "http://ip-api.com/json/{input}?fields=status,message,country,regionName,city,isp,org,as,proxy,hosting,query",
                show=ip_fields, rate=0.5),
        ApiSlot(3, False, "github_user", "EXEMPLO de plataforma: username do GitHub (sem login: 60 req/h)",
                "platform", "GET", "https://api.github.com/users/{name}",
                headers={"Accept": "application/vnd.github+json"}, rate=0.015,
                pattern="[a-z0-9-]{1,39}", rules={"available": [{"status": 404}], "taken": [{"status": 200}]}),
        ApiSlot(4, False, "ipinfo_token", "EXEMPLO com chave no .env (IPINFO_TOKEN)", "lookup", "GET",
                "https://ipinfo.io/{input}/json", headers={"Authorization": "Bearer {env:IPINFO_TOKEN}"},
                show=["ip", "hostname", "city", "region", "country", "org"], rate=0.5),
        ApiSlot(5, False, "", "Slot livre", "lookup", "GET", ""),
    ]


def _coerce(i: int, raw: dict) -> ApiSlot:
    slot = ApiSlot(slot=i)
    known = {f.name for f in fields(ApiSlot)}
    for k, v in (raw or {}).items():
        if k in known and k != "slot":
            setattr(slot, k, v)
    slot.enabled = bool(slot.enabled)
    slot.name = str(slot.name or "").strip()
    slot.description = str(slot.description or "")
    slot.mode = str(slot.mode or "lookup").lower()
    slot.method = str(slot.method or "GET").upper()
    slot.url = str(slot.url or "").strip()
    slot.headers = {str(k): str(v) for k, v in slot.headers.items()} if isinstance(slot.headers, dict) else {}
    try:
        slot.rate = float(slot.rate)
    except (TypeError, ValueError):
        slot.rate = 1.0
    slot.show = [str(x) for x in slot.show] if isinstance(slot.show, list) else []
    slot.run_on_start = bool(slot.run_on_start)
    slot.pattern = str(slot.pattern or "[a-z0-9_]{3,20}")
    slot.rules = slot.rules if isinstance(slot.rules, dict) else {}
    return slot


def load_slots(path=APIS_PATH) -> list[ApiSlot]:
    if not path.is_file():
        slots = default_slots()
        save_slots(slots, path)
        return slots
    try:
        raw = json.loads(path.read_text(encoding="utf-8")).get("slots", [])
    except (ValueError, OSError, AttributeError):
        raw = []
    raw = raw if isinstance(raw, list) else []
    return [_coerce(i + 1, raw[i] if i < len(raw) and isinstance(raw[i], dict) else {})
            for i in range(SLOT_COUNT)]


def save_slots(slots: list[ApiSlot], path=APIS_PATH) -> None:
    data = {"_ajuda": _HELP, "slots": [asdict(s) for s in slots[:SLOT_COUNT]]}
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def find_slot(slots: list[ApiSlot], ref: str) -> ApiSlot | None:
    ref = ref.strip().lower()
    for s in slots:
        if str(s.slot) == ref or (s.slug and s.slug == ref):
            return s
    return None


def validate(slot: ApiSlot) -> list[str]:
    errs = []
    parts = urlsplit(slot.url)
    if parts.scheme not in ("http", "https") or not parts.netloc:
        errs.append("URL deve comecar com http:// ou https://")
    if slot.method not in METHODS:
        errs.append(f"metodo deve ser um de {', '.join(METHODS)}")
    if slot.mode not in MODES:
        errs.append("modo deve ser 'lookup' ou 'platform'")
    if slot.rate <= 0:
        errs.append("rate deve ser > 0")
    if slot.mode == "platform":
        if not re.fullmatch(r"[a-z0-9_]+", slot.slug or ""):
            errs.append("platform precisa de um nome (letras/numeros/_)")
        try:
            re.compile(slot.pattern)
        except re.error as exc:
            errs.append(f"pattern invalido: {exc}")
        blob = json.dumps([slot.url, slot.headers, slot.body], ensure_ascii=False)
        if "{name}" not in blob and "{input}" not in blob:
            errs.append("use {name} na URL, headers ou body (e onde o username entra)")
        if not (slot.rules.get("available") or slot.rules.get("taken")):
            errs.append("defina ao menos uma regra em rules.available ou rules.taken")
    return errs


# ----------------------------------------------------------------- templates
def render(text: str, value: str, *, url: bool = False) -> str:
    def sub(m: re.Match) -> str:
        key = m.group(1)
        if key in ("input", "name"):
            return quote(value, safe="") if url else value
        var = key[4:]
        env = os.environ.get(var)
        if env is None:
            raise ApiError(f"variavel de ambiente ausente: {var} (defina no .env)")
        return quote(env, safe="") if url else env
    return _PLACEHOLDER.sub(sub, text)


def render_obj(obj: Any, value: str) -> Any:
    if isinstance(obj, str):
        return render(obj, value)
    if isinstance(obj, dict):
        return {k: render_obj(v, value) for k, v in obj.items()}
    if isinstance(obj, list):
        return [render_obj(v, value) for v in obj]
    return obj


def build_request(slot: ApiSlot, value: str) -> tuple[str, str, dict]:
    if _PLACEHOLDER.search(slot.url) and ("{input}" in slot.url or "{name}" in slot.url) and not value:
        raise ApiError("esta API precisa de um valor ({input}/{name}) - informe um")
    url = render(slot.url, value, url=True)
    kw: dict[str, Any] = {"headers": {k: render(v, value) for k, v in slot.headers.items()}}
    body = render_obj(slot.body, value)
    if isinstance(body, (dict, list)):
        kw["json"] = body
    elif isinstance(body, str) and body:
        kw["data"] = body
    return slot.method, url, kw


def safe_url(url: str) -> str:
    p = urlsplit(url)
    return f"{p.scheme}://{p.netloc}{p.path}" if p.netloc else url


# --------------------------------------------------------------------- regras
def get_path(obj: Any, path: str) -> tuple[bool, Any]:
    cur = obj
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        elif isinstance(cur, list) and part.isdigit() and int(part) < len(cur):
            cur = cur[int(part)]
        else:
            return False, None
    return True, cur


def _norm_rule(rule: Any) -> dict:
    if isinstance(rule, dict):
        return rule
    if isinstance(rule, int):
        return {"status": rule}
    return {"contains": str(rule)}


def _eq(a: Any, b: Any) -> bool:
    return a == b or str(a).lower() == str(b).lower()


def rule_matches(rule: dict, status: int, text: str, data: Any) -> bool:
    if "status" in rule:
        want = rule["status"] if isinstance(rule["status"], list) else [rule["status"]]
        if status not in [int(x) for x in want]:
            return False
    low = text.lower()
    if "contains" in rule and str(rule["contains"]).lower() not in low:
        return False
    if "not_contains" in rule and str(rule["not_contains"]).lower() in low:
        return False
    if "regex" in rule and not re.search(str(rule["regex"]), text, re.I | re.S):
        return False
    if "json" in rule:
        found, val = get_path(data, str(rule["json"]))
        if "exists" in rule:
            if bool(rule["exists"]) != found:
                return False
        elif "equals" in rule:
            if not found or not _eq(val, rule["equals"]):
                return False
        elif not found:
            return False
    return True


def _json_or_none(text: str) -> Any:
    try:
        return json.loads(text)
    except ValueError:
        return None


def classify(slot: ApiSlot, status: int, text: str) -> Status:
    data = _json_or_none(text)
    for key, verdict in (("invalid", Status.INVALID), ("taken", Status.TAKEN), ("available", Status.AVAILABLE)):
        rules = slot.rules.get(key) or []
        rules = rules if isinstance(rules, list) else [rules]
        for rule in rules:
            if rule_matches(_norm_rule(rule), status, text, data):
                return verdict
    return Status.UNKNOWN


# ------------------------------------------------------------------ execucao
@dataclass
class LookupResult:
    ok: bool
    status: int
    elapsed: float
    error: str | None
    shown: list[tuple[str, str]]
    text: str


@dataclass
class CheckResult:
    status: Status
    http_status: int
    elapsed: float
    error: str | None


def fmt_value(v: Any) -> str:
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False)[:200]
    return str(v)


def flatten(obj: Any, prefix: str = "", depth: int = 0) -> Iterator[tuple[str, str]]:
    if isinstance(obj, dict) and obj and depth < 4:
        for k, v in obj.items():
            yield from flatten(v, f"{prefix}.{k}" if prefix else str(k), depth + 1)
    elif isinstance(obj, list) and obj and depth < 4:
        for i, v in enumerate(obj[:10]):
            yield from flatten(v, f"{prefix}.{i}" if prefix else str(i), depth + 1)
    else:
        yield prefix or "(valor)", fmt_value(obj)


async def _request(slot: ApiSlot, value: str):
    method, url, kw = build_request(slot, value)
    limiter = RateLimiter(slot.rate)
    async with aiohttp.ClientSession(headers={"User-Agent": USER_AGENT}, trust_env=True) as session:
        http = HttpClient(session, limiter, max_retries=3, base_delay=2.0, max_delay=30.0)
        return await http.request(method, url, **kw)


async def run_lookup(slot: ApiSlot, value: str = "") -> LookupResult:
    t0 = time.monotonic()
    try:
        resp = await _request(slot, value)
    except ApiError as exc:
        return LookupResult(False, 0, 0.0, str(exc), [], "")
    except RetriesExhausted as exc:
        return LookupResult(False, 0, time.monotonic() - t0, f"falhou apos tentativas ({exc})", [], "")
    except aiohttp.ClientError as exc:
        return LookupResult(False, 0, time.monotonic() - t0, f"erro de rede ({type(exc).__name__})", [], "")
    data = _json_or_none(resp.text)
    shown: list[tuple[str, str]] = []
    if data is not None:
        if slot.show:
            for path in slot.show:
                found, val = get_path(data, path)
                shown.append((path, fmt_value(val) if found else "—"))
        else:
            shown = list(flatten(data))[:40]
    return LookupResult(200 <= resp.status < 300, resp.status, time.monotonic() - t0, None, shown, resp.text[:5000])


async def run_check(slot: ApiSlot, name: str) -> CheckResult:
    t0 = time.monotonic()
    try:
        resp = await _request(slot, name)
    except ApiError as exc:
        return CheckResult(Status.UNKNOWN, 0, 0.0, str(exc))
    except RetriesExhausted as exc:
        return CheckResult(Status.UNKNOWN, 0, time.monotonic() - t0, f"falhou apos tentativas ({exc})")
    except aiohttp.ClientError as exc:
        return CheckResult(Status.UNKNOWN, 0, time.monotonic() - t0, f"erro de rede ({type(exc).__name__})")
    return CheckResult(classify(slot, resp.status, resp.text), resp.status, time.monotonic() - t0, None)


def format_lookup(slot: ApiSlot, res: LookupResult) -> str:
    if res.error:
        return f"Erro: {res.error}"
    lines = [f"HTTP {res.status} · {res.elapsed:.2f}s · {safe_url(slot.url)}"]
    if res.shown:
        width = max(len(k) for k, _ in res.shown)
        lines += [f"  {k:<{width}}  {v}" for k, v in res.shown]
    else:
        lines.append(res.text[:500] or "(resposta vazia)")
    return "\n".join(lines)


_VERDICTS = {Status.AVAILABLE: "DISPONÍVEL", Status.TAKEN: "EM USO", Status.INVALID: "INVÁLIDO",
             Status.UNKNOWN: "INCONCLUSIVO (nenhuma regra bateu)"}


def format_check(res: CheckResult) -> str:
    if res.error:
        return f"Erro: {res.error}"
    return f"{_VERDICTS[res.status]} · HTTP {res.http_status} · {res.elapsed:.2f}s"


async def run_start_hooks() -> None:
    """Slots 'lookup' com run_on_start: loga o resumo ao iniciar (ex.: seu IP). Nunca derruba a sessao."""
    for slot in load_slots():
        if not (slot.enabled and slot.mode == "lookup" and slot.run_on_start) or validate(slot):
            continue
        try:
            res = await run_lookup(slot, "")
        except Exception as exc:
            log.warning("[api:%s] falhou (%s)", slot.slug, type(exc).__name__)
            continue
        if res.ok and res.shown:
            log.info("[api:%s] %s", slot.slug, ", ".join(f"{k}={v}" for k, v in res.shown[:6]))
        else:
            log.warning("[api:%s] %s", slot.slug, res.error or f"HTTP {res.status}")
