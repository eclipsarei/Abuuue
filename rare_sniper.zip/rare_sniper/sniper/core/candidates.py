"""Candidatos: dicionarios EN/PT + gerador de combinacoes."""
from __future__ import annotations

import itertools
import logging
import re
import unicodedata
from pathlib import Path
from typing import Iterator

import aiohttp

from ..paths import ROOT
from .http import USER_AGENT, HttpClient, RateLimiter
from .types import RetriesExhausted

log = logging.getLogger(__name__)

DEFAULT_DICTS = [
    ROOT / "wordlists" / "en.txt",
    ROOT / "wordlists" / "pt.txt",
    Path("/usr/share/dict/words"),
    Path("/usr/share/dict/brazilian"),
    Path("/usr/share/dict/portuguese"),
]

WORDLIST_URLS = {
    "en": "https://raw.githubusercontent.com/dwyl/english-words/master/words_alpha.txt",
    "pt": "https://raw.githubusercontent.com/pythonprobr/palavras/master/palavras.txt",
}


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="latin-1")


def normalize(word: str) -> str | None:
    w = unicodedata.normalize("NFKD", word.strip().lower())
    w = "".join(c for c in w if not unicodedata.combining(c))  # "acao" <- "ação"
    return w if re.fullmatch(r"[a-z0-9]+", w) else None


def load_words(paths: list[Path], min_len: int, max_len: int) -> list[str]:
    words: set[str] = set()
    for path in paths:
        if not path.is_file():
            continue
        before = len(words)
        for line in _read_text(path).splitlines():
            w = normalize(line)
            if w and min_len <= len(w) <= max_len:
                words.add(w)
        log.info("dicionario %s: +%d palavras", path.name, len(words) - before)
    if not words:
        log.warning("nenhum dicionario encontrado - baixe os completos pelo menu "
                    "(por ora so o gerador sera usado)")
    return sorted(words, key=lambda w: (len(w), w))


def dictionary_summary(paths: list[Path], min_len: int, max_len: int) -> list[tuple[Path, int, int]]:
    """[(arquivo, palavras validas no total, palavras dentro do intervalo de tamanho)]"""
    out = []
    for path in paths:
        if not path.is_file():
            continue
        total = in_range = 0
        for line in _read_text(path).splitlines():
            w = normalize(line)
            if w:
                total += 1
                in_range += min_len <= len(w) <= max_len
        out.append((path, total, in_range))
    return out


def generate(min_len: int, max_len: int, alphabet: str) -> Iterator[str]:
    for length in range(min_len, max_len + 1):
        for combo in itertools.product(alphabet, repeat=length):
            yield "".join(combo)


def candidate_stream(words: list[str], min_len: int, max_len: int, alphabet: str) -> Iterator[str]:
    yield from words
    seen = set(words)
    for name in generate(min_len, max_len, alphabet):
        if name not in seen:
            yield name


def estimate_total(n_words: int, min_len: int, max_len: int, alphabet: str) -> int:
    return n_words + sum(len(alphabet) ** n for n in range(min_len, max_len + 1))


async def download_wordlists(urls: dict[str, str] | None = None) -> list[str]:
    """Baixa dicionarios completos para wordlists/<lang>.txt. Retorna mensagens."""
    urls = urls or WORDLIST_URLS
    dest = ROOT / "wordlists"
    dest.mkdir(exist_ok=True)
    msgs = []
    async with aiohttp.ClientSession(headers={"User-Agent": USER_AGENT}, trust_env=True) as session:
        http = HttpClient(session, RateLimiter(1), base_delay=5.0)
        for lang, url in urls.items():
            log.info("baixando dicionario %s ...", lang.upper())
            try:
                resp = await http.request("GET", url)
            except RetriesExhausted as exc:
                msgs.append(f"{lang.upper()}: falhou ({exc})")
                continue
            if resp.status != 200:
                msgs.append(f"{lang.upper()}: falhou (HTTP {resp.status})")
                continue
            target = dest / f"{lang}.txt"
            target.write_text(resp.text, encoding="utf-8")
            msgs.append(f"{lang.upper()}: salvo em {target.name} ({resp.text.count(chr(10)):,} linhas)")
    for m in msgs:
        log.info(m)
    return msgs
