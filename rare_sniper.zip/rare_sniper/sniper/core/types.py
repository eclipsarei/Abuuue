from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Status(str, Enum):
    AVAILABLE = "available"
    TAKEN = "taken"
    INVALID = "invalid"
    UNKNOWN = "unknown"  # inconclusivo (captcha, erro, retries esgotados...)


@dataclass
class Response:
    status: int
    text: str
    headers: dict[str, str]  # chaves em minusculo


@dataclass
class Hit:
    platform: str  # nome de exibicao
    name: str
    source: str  # "dicionário" ou "combinação"
    confirmed: bool
    url: str | None = None


class RetriesExhausted(Exception):
    """Todas as tentativas (com backoff) falharam."""


class SessionError(Exception):
    """Erro de configuracao/execucao que deve ser mostrado ao usuario."""
