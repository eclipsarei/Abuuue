"""Motor: um PlatformRunner por plataforma (workers + protecoes) e o orquestrador Sniper."""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass

import aiohttp

from ..paths import project_path
from .candidates import DEFAULT_DICTS, candidate_stream, estimate_total, load_words
from .config import Settings
from .http import USER_AGENT, HttpClient, RateLimiter
from .notifier import DiscordWebhookNotifier
from .platform import REGISTRY, Platform, missing_env
from .state import State
from .types import Hit, RetriesExhausted, SessionError, Status

log = logging.getLogger(__name__)


@dataclass
class PlatformStats:
    total: int = 0  # estimativa de candidatos
    checked: int = 0
    skipped: int = 0  # invalidos para a plataforma / ja checados antes
    available: int = 0
    taken: int = 0
    invalid: int = 0
    unknown: int = 0
    suppressed: int = 0
    current: str = "-"
    state: str = "aguardando"
    started: float = 0.0
    unknown_streak: int = 0
    avail_streak: int = 0


class PlatformRunner:
    UNKNOWN_STREAK_LIMIT = 15  # respostas inconclusivas seguidas -> cooldown longo
    LONG_COOLDOWN = 300  # segundos
    AVAILABLE_STREAK_LIMIT = 5  # "disponiveis" seguidos demais = provavel bloqueio/falso positivo

    def __init__(
        self,
        cls: type[Platform],
        settings: Settings,
        words: list[str],
        state: State,
        notifier: DiscordWebhookNotifier | None,
        total: int,
    ):
        self.cls = cls
        self.settings = settings
        self.words = words
        self.word_set = set(words)
        self.state = state
        self.notifier = notifier
        self.stats = PlatformStats(total=total)
        self.limiter = RateLimiter(settings.rate or cls.default_rate)
        self.stop = asyncio.Event()
        self.tag = f"[{cls.name}]"
        self.platform: Platform | None = None

    async def _on_hit(self, name: str) -> None:
        assert self.platform
        try:  # reconfirma antes de avisar
            again = await self.platform.check(name)
        except RetriesExhausted:
            again = Status.UNKNOWN
        if again in (Status.TAKEN, Status.INVALID):
            log.info("%s %s sumiu na reconfirmacao - descartado", self.tag, name)
            return
        confirmed = again is Status.AVAILABLE
        self.stats.available += 1
        log.info("%s DISPONIVEL: %s%s", self.tag, name, "" if confirmed else " (reconfirmacao inconclusiva)")
        self.state.hit(self.cls.name, name, confirmed)
        if self.notifier:
            self.notifier.notify(Hit(
                platform=self.cls.display or self.cls.name,
                name=name,
                source="dicionário" if name in self.word_set else "combinação",
                confirmed=confirmed,
                url=self.platform.profile_url(name),
            ))

    async def run(self) -> None:
        s = self.stats
        s.started = time.monotonic()
        s.state = "rodando"
        conc = self.settings.concurrency
        queue: asyncio.Queue[str | None] = asyncio.Queue(maxsize=conc * 4)
        connector = aiohttp.TCPConnector(limit=conc * 2)
        async with aiohttp.ClientSession(headers={"User-Agent": USER_AGENT}, connector=connector, trust_env=True) as session:
            self.platform = self.cls(HttpClient(session, self.limiter))
            platform = self.platform
            try:
                await platform.setup()
            except Exception as exc:
                s.state = "erro"
                log.error("%s falha no setup: %s", self.tag, type(exc).__name__)
                return

            async def producer() -> None:
                n = 0
                batch: list[str] = []
                for name in candidate_stream(self.words, self.settings.min_len,
                                             self.settings.max_len, self.settings.charset):
                    if self.stop.is_set():
                        break
                    if not platform.is_valid(name) or self.state.seen(self.cls.name, name):
                        s.skipped += 1
                        n += 1
                        if n % 5000 == 0:
                            await asyncio.sleep(0)  # nao trava o event loop
                        continue
                    batch.append(name)
                    if len(batch) >= max(1, platform.batch_size):  # le a cada volta: o plugin pode reduzir
                        await queue.put(batch)
                        batch = []
                if batch:
                    await queue.put(batch)
                for _ in range(conc):
                    await queue.put(None)

            async def worker() -> None:
                while True:
                    names = await queue.get()
                    if names is None:
                        return
                    if self.stop.is_set():
                        continue  # so drena a fila
                    s.current = names[0] if len(names) == 1 else f"{names[0]} (+{len(names) - 1})"
                    try:
                        results = await platform.check_many(names)
                    except RetriesExhausted as exc:
                        log.debug("%s %s: retries esgotados (%s)", self.tag, names[0], exc)
                        results = {}
                    except Exception:
                        log.exception("%s erro inesperado em %s", self.tag, names[0])
                        results = {}
                    for name in names:
                        await self._handle(name, results.get(name, Status.UNKNOWN))

            await asyncio.gather(producer(), *(worker() for _ in range(conc)))
        s.state = "finalizado"
        s.current = "-"
        log.info("%s finalizado (%d checados)", self.tag, s.checked)

    async def _handle(self, name: str, status: Status) -> None:
        s = self.stats
        # Muitos "disponiveis" seguidos quase sempre = bloqueio/endpoint alterado.
        suppressed = False
        if status is Status.AVAILABLE:
            s.avail_streak += 1
            if s.avail_streak > self.AVAILABLE_STREAK_LIMIT:
                suppressed = True
                s.suppressed += 1
                s.state = "suspeito"
                if s.avail_streak == self.AVAILABLE_STREAK_LIMIT + 1:
                    log.warning("%s %d 'disponiveis' seguidos - provavel bloqueio ou endpoint alterado. "
                                "Suprimindo avisos e pausando.", self.tag, s.avail_streak - 1)
                self.limiter.penalize(60)
        elif status is Status.TAKEN:
            s.avail_streak = 0
            if s.state == "suspeito":
                s.state = "rodando"

        # suprimidos voltam a ser candidatos numa proxima execucao
        self.state.record(self.cls.name, name, Status.UNKNOWN if suppressed else status)
        s.checked += 1
        log.debug("%s %s -> %s", self.tag, name, status.value)

        if status is Status.TAKEN:
            s.taken += 1
        elif status is Status.INVALID:
            s.invalid += 1

        if status is Status.UNKNOWN:
            s.unknown += 1
            s.unknown_streak += 1
            if s.unknown_streak >= self.UNKNOWN_STREAK_LIMIT:
                log.warning("%s muitas respostas inconclusivas - cooldown de %ds", self.tag, self.LONG_COOLDOWN)
                self.limiter.penalize(self.LONG_COOLDOWN)
                s.unknown_streak = 0
        else:
            s.unknown_streak = 0

        if status is Status.AVAILABLE and not suppressed:
            await self._on_hit(name)


class Sniper:
    def __init__(self, settings: Settings, notifier: DiscordWebhookNotifier | None):
        self.settings = settings
        self.notifier = notifier
        self.words: list[str] = []
        self.state: State | None = None
        self.runners: list[PlatformRunner] = []

    def prepare(self) -> None:
        s = self.settings
        paths = [project_path(p) for p in s.wordlists] if s.wordlists else DEFAULT_DICTS
        self.words = load_words(paths, s.min_len, s.max_len)
        self.state = State(project_path(s.state_file), project_path(s.hits_file))
        total = estimate_total(len(self.words), s.min_len, s.max_len, s.charset)
        for name in (s.platforms or sorted(REGISTRY)):
            cls = REGISTRY.get(name)
            if cls is None:
                log.error("plataforma desconhecida: %s", name)
                continue
            miss = missing_env(cls)
            if miss:
                log.error("[%s] faltam variaveis de ambiente (%s) - plataforma ignorada", name, ", ".join(miss))
                continue
            self.runners.append(PlatformRunner(cls, s, self.words, self.state, self.notifier, total))
        if not self.runners:
            raise SessionError("Nenhuma plataforma utilizável selecionada.")

    async def run(self) -> None:
        try:
            await asyncio.gather(*(r.run() for r in self.runners))
        finally:
            if self.state:
                self.state.close()

    def stop(self) -> None:
        for r in self.runners:
            r.stop.set()
