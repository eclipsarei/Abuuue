"""Orquestra uma execucao: notificador + motor + painel, e o logging."""
from __future__ import annotations

import asyncio
import contextlib
import logging
import sys

from .core.config import Settings
from .core.engine import Sniper
from .core.notifier import build_notifier
from .core.types import SessionError
from .paths import ROOT


def setup_logging(verbose: bool = False, capture: logging.Handler | None = None) -> None:
    """Arquivo sniper.log sempre; na tela: stdout simples OU a area EVENTOS do painel."""
    root = logging.getLogger("sniper")
    for h in list(root.handlers):
        h.close()
        root.removeHandler(h)
    root.propagate = False
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    fh = logging.FileHandler(ROOT / "sniper.log", encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root.addHandler(fh)
    if capture is not None:
        root.addHandler(capture)
    else:
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%H:%M:%S"))
        root.addHandler(sh)


async def test_notify() -> tuple[bool, str]:
    notifier, err = build_notifier()
    if err or notifier is None:
        return False, err or "webhook nao configurado"
    async with notifier:
        ok = await notifier.send_text("✅ **Sniper conectado.** Teste ok.")
    return ok, ("Mensagem de teste enviada com sucesso." if ok
                else "Falha ao enviar - veja a mensagem de erro acima / sniper.log.")


async def run_session(settings: Settings, capture: logging.Handler | None = None) -> None:
    notifier_cm: contextlib.AbstractAsyncContextManager = contextlib.nullcontext(None)
    if settings.notify:
        notifier, err = build_notifier()
        if err or notifier is None:
            raise SessionError((err or "webhook nao configurado") + " Ou desligue o aviso (--no-notify).")
        notifier_cm = notifier

    async with notifier_cm as notifier:
        if notifier:
            ok = await notifier.send_text("✅ **Sniper conectado.**")
            if not ok:
                raise SessionError("Nao consegui enviar no webhook do Discord - corrija a "
                                   "configuracao ou desligue o aviso (--no-notify).")
        try:  # APIs customizaveis marcadas com run_on_start (ex.: loga o seu IP)
            from .core.custom_api import run_start_hooks
            await run_start_hooks()
        except Exception:
            pass
        sniper = Sniper(settings, notifier)
        sniper.prepare()
        dash_task = None
        if capture is not None:
            from .ui.dashboard import Dashboard
            dash_task = asyncio.create_task(Dashboard(sniper, notifier, capture).run())  # type: ignore[arg-type]
        try:
            await sniper.run()
        finally:
            if dash_task:
                dash_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await dash_task


def start(settings: Settings, use_dashboard: bool, verbose: bool = False) -> int:
    """Roda ate acabar ou ate Ctrl+C. Retorna o codigo de saida."""
    capture = None
    if use_dashboard:
        from .ui.ansi import clear_screen
        from .ui.banner import banner
        from .ui.dashboard import LogCapture
        capture = LogCapture()
        clear_screen()
        print(banner())
    setup_logging(verbose, capture)
    code = 0
    try:
        asyncio.run(run_session(settings, capture))
    except KeyboardInterrupt:
        print("\nInterrompido - progresso salvo (retome rodando de novo).")
    except SessionError as exc:
        print(f"\nErro: {exc}")
        code = 1
    finally:
        setup_logging(verbose)  # volta o log para stdout
    return code
