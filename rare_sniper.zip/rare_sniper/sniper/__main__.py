from sniper.cli import main

raise SystemExit(main())
