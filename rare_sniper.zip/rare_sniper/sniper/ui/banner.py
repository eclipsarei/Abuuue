"""Banner: SNIPER em ASCII + creditos."""
from __future__ import annotations

from .. import CREDITS, __version__
from .ansi import BOLD, DIM, c, fg256

GLYPHS = {
    "S": ["███████╗", "██╔════╝", "███████╗", "╚════██║", "███████║", "╚══════╝"],
    "N": ["███╗   ██╗", "████╗  ██║", "██╔██╗ ██║", "██║╚██╗██║", "██║ ╚████║", "╚═╝  ╚═══╝"],
    "I": ["██╗", "██║", "██║", "██║", "██║", "╚═╝"],
    "P": ["██████╗ ", "██╔══██╗", "██████╔╝", "██╔═══╝ ", "██║     ", "╚═╝     "],
    "E": ["███████╗", "██╔════╝", "█████╗  ", "██╔══╝  ", "███████╗", "╚══════╝"],
    "R": ["██████╗ ", "██╔══██╗", "██████╔╝", "██╔══██╗", "██║  ██║", "╚═╝  ╚═╝"],
}
GRADIENT = [196, 160, 160, 124, 124, 88]  # vermelho -> bordo


def art_lines(word: str = "SNIPER") -> list[str]:
    return ["".join(GLYPHS[ch][row] for ch in word) for row in range(6)]


def banner() -> str:
    art = art_lines()
    width = len(art[0])
    out = [""]
    for line, shade in zip(art, GRADIENT):
        out.append("  " + c(line, fg256(shade), BOLD))
    credit = f"── sniper by {CREDITS} ──"
    out.append("  " + c(credit.center(width), fg256(160)))
    out.append("  " + c(f"v{__version__} · modular · aviso via webhook".center(width), DIM))
    out.append("")
    return "\n".join(out)
