"""Helpers de cor/terminal (so ANSI, sem dependencias)."""
from __future__ import annotations

import os
import re
import sys

RESET = "\x1b[0m"
BOLD = "\x1b[1m"
DIM = "\x1b[2m"
RED = "\x1b[31m"
GREEN = "\x1b[32m"
YELLOW = "\x1b[33m"
CYAN = "\x1b[36m"
MAGENTA = "\x1b[35m"
HIDE_CURSOR = "\x1b[?25l"
SHOW_CURSOR = "\x1b[?25h"

_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def color_enabled() -> bool:
    return sys.stdout.isatty() and not os.environ.get("NO_COLOR")


def c(text: str, *codes: str) -> str:
    if not codes or not color_enabled():
        return text
    return "".join(codes) + text + RESET


def fg256(n: int) -> str:
    return f"\x1b[38;5;{n}m"


def strip_ansi(s: str) -> str:
    return _ANSI.sub("", s)


def fit(s: str, width: int) -> str:
    """Corta a linha na largura visivel, preservando as sequencias ANSI."""
    if len(strip_ansi(s)) <= width:
        return s
    out, vis = [], 0
    for tok in re.split(r"(\x1b\[[0-9;?]*[A-Za-z])", s):
        if _ANSI.fullmatch(tok):
            out.append(tok)
            continue
        room = width - vis
        if room > 0:
            out.append(tok[:room])
            vis += min(len(tok), room)
    return "".join(out) + RESET


def clear_screen() -> None:
    if sys.stdout.isatty():
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.flush()
