"""Interface de texto (banner, menu e painel ao vivo)."""
