"""Menu interativo."""
from __future__ import annotations

import asyncio
import json
import os
import sys
from dataclasses import replace

from ..core.candidates import (DEFAULT_DICTS, WORDLIST_URLS, dictionary_summary,
                               download_wordlists, estimate_total)
from ..core import custom_api as ca
from ..core.config import Settings, save_settings
from ..core.notifier import webhook_configured
from ..core.platform import REGISTRY, missing_env
from ..paths import ROOT, project_path
from ..platforms import LOAD_ERRORS
from ..platforms import custom_api as custom_platforms
from ..session import start, test_notify
from .ansi import BOLD, DIM, GREEN, RED, YELLOW, c, clear_screen
from .banner import banner

_dict_cache: dict = {}


def ask(prompt: str) -> str:
    try:
        return input(prompt).strip()
    except EOFError:
        raise KeyboardInterrupt


def pause(msg: str = "Enter para continuar...") -> None:
    ask(c(f"\n  {msg}", DIM))


def screen(title: str | None = None) -> None:
    clear_screen()
    print(banner())
    if title:
        print(c(f"  ▌ {title}", BOLD))
        print()


def ask_int(prompt: str, current: int, lo: int, hi: int) -> int:
    raw = ask(f"  {prompt} [{lo}-{hi}] (atual {current}): ")
    if raw.isdigit() and lo <= int(raw) <= hi:
        return int(raw)
    if raw:
        print(c("  valor inválido - mantido", YELLOW))
    return current


def _dict_paths(s: Settings):
    return [project_path(p) for p in s.wordlists] if s.wordlists else DEFAULT_DICTS


def _dicts(s: Settings):
    paths = _dict_paths(s)
    key = (tuple((str(p), p.stat().st_mtime_ns if p.is_file() else 0) for p in paths), s.min_len, s.max_len)
    if key not in _dict_cache:
        _dict_cache.clear()
        _dict_cache[key] = dictionary_summary(paths, s.min_len, s.max_len)
    return _dict_cache[key]


def show_summary(s: Settings) -> None:
    names = s.platforms or sorted(REGISTRY)
    wh = webhook_configured()
    dicts = _dicts(s)
    n_words = sum(d[2] for d in dicts)
    total = estimate_total(n_words, s.min_len, s.max_len, s.charset)
    print(f"  Plataformas : {c(', '.join(names), GREEN)}")
    print(f"  Tamanho     : {s.min_len}–{s.max_len} caracteres · dígitos: {'sim' if s.digits else 'não'}"
          f" · extras: {s.extra_chars or '—'}")
    print(f"  Velocidade  : {str(s.rate) + ' req/s' if s.rate else 'padrão de cada plataforma'}"
          f" · workers: {s.concurrency}")
    hook = c("● webhook configurado", GREEN) if wh else c("○ webhook NÃO configurado (.env)", RED)
    print(f"  Aviso       : {hook} · {'ligado' if s.notify else 'desligado'}")
    print(f"  Candidatos  : ~{total:,} por plataforma ({n_words:,} palavras de dicionário + combinações)"
          .replace(",", "."))
    print()


def _platforms_menu(s: Settings) -> None:
    while True:
        screen("Plataformas")
        names = sorted(REGISTRY)
        active = set(s.platforms or names)
        for i, n in enumerate(names, 1):
            cls = REGISTRY[n]
            mark = c("[x]", GREEN) if n in active else "[ ]"
            miss = missing_env(cls)
            warn = c(f"  (falta: {', '.join(miss)})", RED) if miss else ""
            print(f"  {i}) {mark} {cls.display:<10} {c(cls.description, DIM)}{warn}")
        print(c("\n  número = ativar/desativar · a = todas · 0 = voltar", DIM))
        choice = ask("  > ").lower()
        if choice in ("0", ""):
            return
        if choice == "a":
            s.platforms = []
        elif choice.isdigit() and 1 <= int(choice) <= len(names):
            n = names[int(choice) - 1]
            new = set(active) ^ {n}
            if not new:
                print(c("  mantenha pelo menos uma plataforma ativa", YELLOW))
                pause()
                continue
            s.platforms = [] if new == set(names) else sorted(new)
        save_settings(s)


def _settings_menu(s: Settings) -> None:
    while True:
        screen("Configurações")
        rows = [
            ("Tamanho mínimo", s.min_len), ("Tamanho máximo", s.max_len),
            ("Incluir dígitos 0-9", "sim" if s.digits else "não"),
            ("Caracteres extras (_ .)", s.extra_chars or "—"),
            ("Workers por plataforma", s.concurrency),
            ("Velocidade (req/s)", s.rate or "padrão de cada plataforma"),
            ("Aviso no Discord", "ligado" if s.notify else "desligado"),
            ("Arquivos de dicionário", ", ".join(s.wordlists) if s.wordlists else "padrão (wordlists/en.txt, pt.txt)"),
        ]
        for i, (k, v) in enumerate(rows, 1):
            print(f"  {i}) {k:<26} {c(str(v), GREEN)}")
        print(c("\n  0 = voltar   (menos req/s = menos risco de bloqueio)", DIM))
        ch = ask("  > ")
        if ch in ("0", ""):
            return
        print()
        if ch == "1":
            s.min_len = ask_int("Tamanho mínimo", s.min_len, 1, 12)
        elif ch == "2":
            s.max_len = ask_int("Tamanho máximo", s.max_len, 1, 12)
        elif ch == "3":
            s.digits = not s.digits
        elif ch == "4":
            s.extra_chars = ask("  Caracteres extras (ex.: _.  vazio = nenhum): ")
        elif ch == "5":
            s.concurrency = ask_int("Workers", s.concurrency, 1, 10)
        elif ch == "6":
            raw = ask("  Req/s (ex.: 0.5 · vazio = padrão): ")
            try:
                s.rate = float(raw.replace(",", ".")) if raw else None
            except ValueError:
                print(c("  valor inválido - mantido", YELLOW)); pause()
        elif ch == "7":
            s.notify = not s.notify
        elif ch == "8":
            raw = ask("  Caminhos separados por vírgula (vazio = padrão): ")
            s.wordlists = [p.strip() for p in raw.split(",") if p.strip()]
        s.validate()
        save_settings(s)


def _dicts_menu(s: Settings) -> None:
    while True:
        screen("Dicionários (EN + PT)")
        found = _dicts(s)
        if not found:
            print(c("  nenhum dicionário encontrado em wordlists/", YELLOW))
        for path, total, in_range in found:
            try:
                shown = path.relative_to(ROOT)
            except ValueError:
                shown = path
            print(f"  • {str(shown):<28} {total:>8,} palavras · {in_range:>6,} com {s.min_len}-{s.max_len} caracteres"
                  .replace(",", "."))
        print("\n  1) Baixar dicionários completos (EN: dwyl/english-words · PT: pythonprobr/palavras)")
        print("     (sobrescreve wordlists/en.txt e pt.txt)")
        print(c("  0) Voltar", DIM))
        ch = ask("  > ")
        if ch in ("0", ""):
            return
        if ch == "1":
            print()
            asyncio.run(download_wordlists(WORDLIST_URLS))
            pause()


def _plugins_menu() -> None:
    screen("Plugins de plataforma")
    for n in sorted(REGISTRY):
        cls = REGISTRY[n]
        miss = missing_env(cls)
        status = c("pronto", GREEN) if not miss else c(f"falta {', '.join(miss)}", RED)
        print(f"  • {cls.display:<10} id={n:<8} {cls.default_rate} req/s · {status}")
        print(c(f"      {cls.description}", DIM))
    for mod, err in LOAD_ERRORS.items():
        print(c(f"  ✖ {mod}: {err}", RED))
    print(c("\n  Adicionar plataforma: copie sniper/platforms/_template.py para",
            DIM))
    print(c("  sniper/platforms/<nome>.py, descomente @register e implemente check().", DIM))
    pause()


def _test_notify() -> None:
    screen("Testar aviso no Discord")
    if not webhook_configured():
        print(c("  DISCORD_WEBHOOK_URL ausente/inválida no .env (veja .env.example).", RED))
    else:
        ok, msg = asyncio.run(test_notify())
        print(c(f"  {msg}", GREEN if ok else RED))
    pause()


def _start(s: Settings, verbose: bool) -> None:
    run_settings = s
    if s.notify and not webhook_configured():
        print(c("\n  Webhook do Discord não configurado - você não seria avisado dos achados.", YELLOW))
        if ask("  Iniciar mesmo assim, sem avisos? [s/N] ").lower() != "s":
            return
        run_settings = replace(s, notify=False)
    start(run_settings, use_dashboard=sys.stdout.isatty(), verbose=verbose)
    pause("Enter para voltar ao menu...")


# ----------------------------------------------------------- APIs customizaveis
def _indent(text: str) -> None:
    print("\n".join("  " + line for line in text.splitlines()))


def _csv_ints(raw: str) -> list[int]:
    return [int(x) for x in (p.strip() for p in raw.split(",")) if x.isdigit()]


def _csv_texts(raw: str) -> list[str]:
    return [x for x in (p.strip() for p in raw.split(",")) if x]


def _edit_slot(slot: ca.ApiSlot) -> None:
    print(c("  Enter = manter o valor atual · '-' = limpar\n", DIM))

    def text(label: str, current: str) -> str:
        raw = ask(f"  {label} [{current}]: ")
        return current if not raw else ("" if raw == "-" else raw)

    slot.name = text("Nome (id; letras/números/_)", slot.name)
    slot.description = text("Descrição", slot.description)
    raw = ask(f"  Modo: 1) consulta manual (lookup)  2) plataforma de username [{slot.mode}]: ")
    slot.mode = {"1": "lookup", "2": "platform"}.get(raw, slot.mode)
    raw = ask(f"  Método {'/'.join(ca.METHODS)} [{slot.method}]: ").upper()
    slot.method = raw if raw in ca.METHODS else slot.method
    print(c("  Placeholders: {input} ou {name} = valor consultado · {env:VAR} = variável do .env", DIM))
    slot.url = text("URL", slot.url)
    print(f"  Headers atuais: {', '.join(slot.headers) or 'nenhum'}")
    if ask("  Alterar headers? [s/N] ").lower() == "s":
        slot.headers = {}
        print(c("    'Chave: Valor' por linha (ex.: Authorization: Bearer {env:MINHA_CHAVE}); vazio termina", DIM))
        while True:
            line = ask("    > ")
            if not line:
                break
            if ":" not in line:
                print(c("    formato inválido", YELLOW))
                continue
            k, _, v = line.partition(":")
            slot.headers[k.strip()] = v.strip()
    raw = ask("  Body (texto ou JSON; Enter=manter, '-'=limpar): ")
    if raw == "-":
        slot.body = None
    elif raw:
        try:
            slot.body = json.loads(raw) if raw[:1] in "{[" else raw
        except ValueError:
            slot.body = raw
    raw = ask(f"  Velocidade req/s [{slot.rate}]: ").replace(",", ".")
    try:
        slot.rate = float(raw) if raw else slot.rate
    except ValueError:
        print(c("  valor inválido - mantido", YELLOW))
    if slot.mode == "lookup":
        raw = ask(f"  Campos JSON a mostrar, separados por vírgula (a.b.0.c) [{','.join(slot.show) or 'todos'}]: ")
        if raw:
            slot.show = [] if raw == "-" else _csv_texts(raw)
        raw = ask(f"  Rodar ao iniciar o sniper e logar o resumo? s/n (atual {'s' if slot.run_on_start else 'n'}): ").lower()
        if raw in ("s", "n"):
            slot.run_on_start = raw == "s"
    else:
        slot.pattern = text("Regex de username válido (ex.: [a-z0-9_]{3,20})", slot.pattern)
        if ask("  Reconfigurar regras de resposta? (substitui as atuais) [s/N] ").lower() == "s":
            print(c("  Informe o que a resposta tem em cada caso; vários valores separados por vírgula.", DIM))
            av_st = _csv_ints(ask("    Status HTTP = DISPONÍVEL (ex.: 404): "))
            tk_st = _csv_ints(ask("    Status HTTP = EM USO (ex.: 200): "))
            av_tx = _csv_texts(ask("    Texto na resposta = DISPONÍVEL: "))
            tk_tx = _csv_texts(ask("    Texto na resposta = EM USO: "))
            slot.rules = {
                "available": [{"status": n} for n in av_st] + [{"contains": t} for t in av_tx],
                "taken": [{"status": n} for n in tk_st] + [{"contains": t} for t in tk_tx],
            }
            print(c("  (regras avançadas por caminho JSON: edite apis.json)", DIM))


def _save_apis(slots: list[ca.ApiSlot]) -> None:
    ca.save_slots(slots)
    custom_platforms.reload()


def _api_slot_menu(n: int) -> None:
    while True:
        slots = ca.load_slots()
        slot = slots[n - 1]
        screen(f"API {n} — {slot.name or '(livre)'}")
        mode = "consulta manual (lookup)" if slot.mode == "lookup" else "plataforma de username"
        print(f"  Estado   : {c('ligada', GREEN) if slot.enabled else c('desligada', DIM)}")
        print(f"  Modo     : {mode}")
        print(f"  Pedido   : {slot.method} {ca.safe_url(slot.url) or '(sem URL)'}  ·  {slot.rate} req/s")
        if slot.headers:
            print(f"  Headers  : {', '.join(slot.headers)}")
        missing = [v for v in slot.env_vars() if not os.environ.get(v)]
        for var in slot.env_vars():
            ok = var not in missing
            print(f"  .env     : {var} {c('✔', GREEN) if ok else c('✖ ausente', RED)}")
        errs = ca.validate(slot) if (slot.url or slot.name) else []
        for e in errs:
            print(c(f"  ! {e}", YELLOW))
        print("\n  1) Consultar / testar agora")
        print("  2) Editar (assistente)")
        print("  3) Ligar / desligar")
        print("  4) Limpar slot")
        print(c("  0) Voltar  (avançado: edite apis.json)", DIM))
        ch = ask("  > ")
        if ch in ("0", ""):
            return
        if ch == "1":
            if errs:
                print(c("\n  Corrija os avisos acima antes de testar.", YELLOW))
            elif slot.mode == "lookup":
                value = ask("\n  Valor para {input} (ex.: um IP; vazio se a API não usa): ")
                _indent(ca.format_lookup(slot, asyncio.run(ca.run_lookup(slot, value))))
            else:
                value = ask("\n  Username para testar: ")
                _indent(ca.format_check(asyncio.run(ca.run_check(slot, value))))
            pause()
        elif ch == "2":
            screen(f"Editar API {n}")
            _edit_slot(slot)
            errs = ca.validate(slot)
            if errs:
                print(c("\n  Configuração incompleta:", YELLOW))
                for e in errs:
                    print(c(f"   - {e}", YELLOW))
                slot.enabled = False
                print(c("  Slot salvo DESLIGADO. Corrija e ligue em '3'.", YELLOW))
            else:
                slot.enabled = ask("\n  Ligar este slot agora? [S/n] ").lower() != "n"
            _save_apis(slots)
            pause()
        elif ch == "3":
            if not slot.enabled and errs:
                print(c("\n  Não dá para ligar: " + "; ".join(errs), YELLOW))
                pause()
                continue
            slot.enabled = not slot.enabled
            _save_apis(slots)
        elif ch == "4":
            if ask("  Limpar este slot? [s/N] ").lower() == "s":
                slots[n - 1] = ca.ApiSlot(slot=n, description="Slot livre")
                _save_apis(slots)


def _apis_menu() -> None:
    while True:
        screen("APIs customizáveis (5 entradas)")
        for sl in ca.load_slots():
            mark = c("[x]", GREEN) if sl.enabled else "[ ]"
            mode = "consulta" if sl.mode == "lookup" else "plataforma"
            print(f"  {sl.slot}) {mark} {(sl.name or '(livre)'):<14} {c(mode, DIM):<22} "
                  f"{c(ca.safe_url(sl.url) or '-', DIM)}")
        print(c("\n  Consulta = você pergunta (ex.: info de um IP) · Plataforma = vira um sniper de username", DIM))
        print(c("  número = abrir o slot · 0 = voltar · CLI: main.py --api SLOT VALOR", DIM))
        ch = ask("  > ")
        if ch in ("0", ""):
            return
        if ch.isdigit() and 1 <= int(ch) <= ca.SLOT_COUNT:
            _api_slot_menu(int(ch))


def run_menu(s: Settings, verbose: bool = False) -> None:
    while True:
        screen()
        show_summary(s)
        print("  1) Iniciar sniper")
        print("  2) Plataformas")
        print("  3) Configurações")
        print("  4) Testar aviso no Discord")
        print("  5) Dicionários")
        print("  6) Plugins")
        print("  7) APIs customizáveis (consulta de IP etc.)")
        print(c("  0) Sair", DIM))
        ch = ask("\n  > ")
        if ch == "1":
            _start(s, verbose)
        elif ch == "2":
            _platforms_menu(s)
        elif ch == "3":
            _settings_menu(s)
        elif ch == "4":
            _test_notify()
        elif ch == "5":
            _dicts_menu(s)
        elif ch == "6":
            _plugins_menu()
        elif ch == "7":
            _apis_menu()
        elif ch in ("0", "q", "sair"):
            print(c("\n  até mais — sniper by 385 tepes & krypt\n", DIM))
            return
