"""Painel ao vivo (redesenha no lugar) + captura de logs para a area de eventos."""
from __future__ import annotations

import asyncio
import collections
import logging
import shutil
import sys
import time

from ..core.engine import PlatformRunner, Sniper
from ..core.notifier import DiscordWebhookNotifier
from .ansi import (BOLD, CYAN, DIM, GREEN, HIDE_CURSOR, RED, SHOW_CURSOR, YELLOW,
                   c, fit)


class LogCapture(logging.Handler):
    """Guarda os ultimos logs para a area EVENTOS (em vez de imprimir por cima do painel)."""

    def __init__(self, maxlen: int = 200):
        super().__init__(level=logging.INFO)
        self.events: collections.deque = collections.deque(maxlen=maxlen)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.events.append((record.created, record.levelno, record.getMessage()))
        except Exception:
            pass


def fmt_int(n: int) -> str:
    return f"{n:,}".replace(",", ".")


def fmt_clock(sec: float) -> str:
    sec = int(sec)
    return f"{sec // 3600:02d}:{sec % 3600 // 60:02d}:{sec % 60:02d}"


def fmt_eta(sec: float) -> str:
    if sec != sec or sec == float("inf") or sec <= 0:
        return "—"
    sec = int(sec)
    d, rem = divmod(sec, 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    if d:
        return f"~{d}d {h}h"
    if h:
        return f"~{h}h {m}m"
    if m:
        return f"~{m}m {s}s"
    return f"~{s}s"


def bar(frac: float, width: int = 8) -> str:
    frac = max(0.0, min(1.0, frac))
    fill = int(round(frac * width))
    return "[" + "█" * fill + "░" * (width - fill) + "]"


class Dashboard:
    EVENT_LINES = 8

    def __init__(self, sniper: Sniper, notifier: DiscordWebhookNotifier | None,
                 capture: LogCapture, refresh: float = 1.0):
        self.sniper = sniper
        self.notifier = notifier
        self.capture = capture
        self.refresh = refresh
        self.t0 = time.monotonic()
        self._prev: dict[str, tuple[float, int]] = {}
        self._rates: dict[str, float] = {}
        self._drawn = 0

    # ---------------------------------------------------------------- render
    def _inst_rate(self, r: PlatformRunner, now: float) -> float:
        prev = self._prev.get(r.cls.name)
        if prev is None or now - prev[0] >= 2.0:
            if prev is not None:
                self._rates[r.cls.name] = (r.stats.checked - prev[1]) / (now - prev[0])
            self._prev[r.cls.name] = (now, r.stats.checked)
        return self._rates.get(r.cls.name, 0.0)

    def _state_label(self, r: PlatformRunner) -> str:
        s = r.stats
        cd = r.limiter.cooldown_remaining()
        if s.state == "rodando" and cd > 1:
            return c(f"pausa {int(cd)}s"[:11], YELLOW)
        color = {"rodando": GREEN, "suspeito": RED, "erro": RED, "finalizado": CYAN}.get(s.state, DIM)
        return c(s.state[:11], color)

    def render(self) -> list[str]:
        now = time.monotonic()
        sep = c("─" * 76, DIM)
        if self.notifier:
            hook = c("● ativo", GREEN) + f" ({self.notifier.sent} enviados"
            if self.notifier.failed:
                hook += c(f", {self.notifier.failed} falhas", RED)
            hook += ")"
        else:
            hook = c("○ desligado", DIM)
        lines = [
            f" tempo {c(fmt_clock(now - self.t0), BOLD)}   dicionário {fmt_int(len(self.sniper.words))} palavras"
            f"   aviso Discord: {hook}",
            sep,
            c(f" {'PLATAF.':<9} {'ESTADO':<11} {'CHECADOS':>8} {'REQ/S':>7} {'DISP':>5} {'INCONC':>6}"
              f"  {'PROGRESSO':<10} {'':>4} {'ETA':<8}", BOLD),
        ]
        for r in self.sniper.runners:
            s = r.stats
            rate = self._inst_rate(r, now)
            elapsed = max(1.0, now - s.started) if s.started else 1.0
            avg = s.checked / elapsed
            done = s.checked + s.skipped
            frac = done / s.total if s.total else 0.0
            remaining = max(0, s.total - done)
            eta = fmt_eta(remaining / avg) if avg > 0 and s.state != "finalizado" else "—"
            avail = c(f"{s.available:>5}", GREEN, BOLD) if s.available else f"{0:>5}"
            label = self._state_label(r)
            pad = " " * max(0, 11 - len(_plain(label)))
            lines.append(
                f" {r.cls.name[:9]:<9} {label}{pad} {fmt_int(s.checked):>8} {rate:>5.2f}/s {avail} {s.unknown:>6}"
                f"  {bar(frac)} {min(frac, 1.0) * 100:>3.0f}% {eta:<8}"
            )
            lines.append(c(f"   └ testando: {s.current}", DIM))
        lines += [sep, c(" EVENTOS", BOLD)]
        evs = list(self.capture.events)[-self.EVENT_LINES:]
        for ts, lvl, msg in evs:
            stamp = time.strftime("%H:%M:%S", time.localtime(ts))
            color = RED if lvl >= logging.ERROR else YELLOW if lvl >= logging.WARNING else \
                (GREEN if "DISPONIVEL" in msg else None)
            text = f" {stamp} {msg}"
            lines.append(c(text, color, BOLD) if color == GREEN else (c(text, color) if color else text))
        lines += [""] * (self.EVENT_LINES - len(evs))
        lines += [sep, c(" Ctrl+C para parar · progresso salvo · achados em hits.txt · log em sniper.log", DIM)]
        return lines

    # ----------------------------------------------------------------- draw
    def draw(self) -> None:
        cols = shutil.get_terminal_size((80, 24)).columns
        lines = [fit(l, max(20, cols - 1)) for l in self.render()]
        out = sys.stdout
        if self._drawn:
            out.write(f"\x1b[{self._drawn}F")
        out.write("".join(f"\x1b[K{l}\n" for l in lines))
        out.flush()
        self._drawn = len(lines)

    async def run(self) -> None:
        sys.stdout.write(HIDE_CURSOR)
        try:
            while True:
                self.draw()
                await asyncio.sleep(self.refresh)
        finally:
            try:
                self.draw()
            finally:
                sys.stdout.write(SHOW_CURSOR)
                sys.stdout.flush()


def _plain(s: str) -> str:
    from .ansi import strip_ansi
    return strip_ansi(s)
