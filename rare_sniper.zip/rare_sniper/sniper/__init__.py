"""sniper by 385 tepes & krypt - verificador modular de usernames raros."""
__version__ = "2.2.0"
CREDITS = "385 tepes & krypt"
