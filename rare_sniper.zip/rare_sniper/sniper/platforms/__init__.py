"""Auto-descoberta de plataformas.

Todo arquivo .py desta pasta (exceto os que comecam com "_") e importado
automaticamente; as classes decoradas com @register entram no REGISTRY.
Um plugin quebrado NAO derruba os outros: o erro vai para LOAD_ERRORS.
"""
from __future__ import annotations

import importlib
import logging
import pkgutil

log = logging.getLogger(__name__)

LOAD_ERRORS: dict[str, str] = {}


def load_all() -> dict[str, str]:
    LOAD_ERRORS.clear()
    for mod in pkgutil.iter_modules(__path__):
        if mod.name.startswith("_"):
            continue
        try:
            importlib.import_module(f"{__name__}.{mod.name}")
        except Exception as exc:  # plugin quebrado: registra e segue
            LOAD_ERRORS[mod.name] = f"{type(exc).__name__}: {exc}"
            log.error("plugin %s nao carregou: %s", mod.name, LOAD_ERRORS[mod.name])
    return LOAD_ERRORS
