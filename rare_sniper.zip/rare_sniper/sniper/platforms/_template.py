"""TEMPLATE para uma plataforma nova (arquivos que comecam com "_" NAO sao carregados).

Como adicionar uma plataforma em 3 passos:
  1. cp sniper/platforms/_template.py sniper/platforms/minhaplataforma.py
  2. Edite os atributos e o check() abaixo e DESCOMENTE o @register.
  3. Rode `python3 main.py --list-platforms` - ela ja aparece no menu e na CLI.
Nao precisa mexer em mais nenhum arquivo.
"""
from __future__ import annotations

import re

from sniper.core.platform import Platform, register  # noqa: F401
from sniper.core.types import Status


# @register   # <- descomente na sua copia
class Exemplo(Platform):
    name = "exemplo"  # id curto (CLI/estado)
    display = "Exemplo"  # nome nas mensagens
    description = "Usernames do Exemplo (3-20: a-z 0-9 _)"
    pattern = re.compile(r"[a-z0-9_]{3,20}")  # nome valido (fullmatch)
    default_rate = 1.0  # req/s conservador; o motor desacelera sozinho em 429/529
    requires_env: tuple[str, ...] = ()  # ex.: ("EXEMPLO_API_KEY",) - checado antes de iniciar

    async def setup(self) -> None:
        """Opcional: busque cookies/tokens de guest aqui (roda 1x antes de comecar)."""

    def extra_rules(self, name: str) -> bool:
        return True  # regras alem do regex

    def profile_url(self, name: str) -> str | None:
        return f"https://exemplo.com/{name}"  # link mostrado no aviso (ou None)

    async def check(self, name: str) -> Status:
        # self.http.request(...) ja faz rate limit, retry e backoff (429/5xx/529).
        resp = await self.http.request("GET", f"https://exemplo.com/api/check/{name}")
        if resp.status == 404:
            return Status.AVAILABLE
        if resp.status == 200:
            return Status.TAKEN
        return Status.UNKNOWN  # captcha, bloqueio, resposta estranha...
