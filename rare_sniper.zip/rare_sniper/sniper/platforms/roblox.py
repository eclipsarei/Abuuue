"""Plataforma: Roblox.

Melhoria (pesquisa em clientes existentes da API): a rota de busca por nome aceita VARIOS
nomes por requisicao. O plugin consulta 100 por vez; quem NAO aparece no lote e candidato
e so entao passa pela validacao individual (que separa livre / inapropriado / invalido).
"""
from __future__ import annotations

import json
import logging
import re

from sniper.core.platform import Platform, register
from sniper.core.types import Status

log = logging.getLogger(__name__)


@register
class Roblox(Platform):
    name = "roblox"
    display = "Roblox"
    description = "Usernames do Roblox (3-20: letras, numeros, 1 underscore) - consulta em lote"
    pattern = re.compile(r"[A-Za-z0-9_]{3,20}")
    default_rate = 0.5  # req/s - cada requisicao leva ate 100 nomes
    batch_size = 100
    CHECK_URL = "https://auth.roblox.com/v1/usernames/validate"
    BATCH_URL = "https://users.roblox.com/v1/usernames/users"

    def extra_rules(self, name: str) -> bool:
        return not name.startswith("_") and not name.endswith("_") and name.count("_") <= 1

    async def check(self, name: str) -> Status:
        """Validacao individual (usada nos candidatos e na reconfirmacao)."""
        resp = await self.http.request(
            "GET", self.CHECK_URL,
            params={"Username": name, "Birthday": "2000-01-01", "Context": "Signup"},
        )
        if resp.status != 200:
            return Status.UNKNOWN
        try:
            code = json.loads(resp.text).get("code")
        except (ValueError, AttributeError):
            return Status.UNKNOWN
        if code == 0:
            return Status.AVAILABLE
        if code == 1:
            return Status.TAKEN
        return Status.INVALID  # inapropriado / caracteres invalidos / etc.

    async def check_many(self, names: list[str]) -> dict[str, Status]:
        resp = await self.http.request(
            "POST", self.BATCH_URL, json={"usernames": names, "excludeBannedUsers": False},
        )
        if resp.status == 400 and len(names) > 10:
            # lote grande demais para a API: reduz o tamanho e cai para consulta individual
            self.batch_size = max(10, len(names) // 2)
            log.warning("[roblox] lote recusado (HTTP 400) - novo tamanho de lote: %d", self.batch_size)
            return {n: await self.check(n) for n in names}
        if resp.status != 200:
            return {n: Status.UNKNOWN for n in names}
        try:
            data = json.loads(resp.text).get("data", [])
        except (ValueError, AttributeError):
            return {n: Status.UNKNOWN for n in names}
        in_use: set[str] = set()
        for item in data if isinstance(data, list) else []:
            for key in ("requestedUsername", "name"):
                value = item.get(key) if isinstance(item, dict) else None
                if value:
                    in_use.add(str(value).lower())
        out: dict[str, Status] = {}
        for n in names:
            # banidos tambem voltam no lote (excludeBannedUsers=False); so o que sobra e candidato
            out[n] = Status.TAKEN if n.lower() in in_use else await self.check(n)
        return out
