"""Plataforma: TikTok (pagina publica do perfil).

Melhoria (pesquisa em checkers existentes): alem do 404/200, le o JSON embutido na pagina
(__UNIVERSAL_DATA_FOR_REHYDRATION__ -> webapp.user-detail.statusCode):
    0 = perfil existe | 10202 = usuario nao existe | outros (banido, privado...) = indisponivel.
So 10202 / 404 / "Couldn't find this account" contam como livre; qualquer outro codigo conta
como EM USO, o que reduz falso positivo de contas banidas/reservadas. Captcha/verificacao pausa a plataforma.
"""
from __future__ import annotations

import json
import logging
import re

from sniper.core.platform import Platform, register
from sniper.core.types import Status

log = logging.getLogger(__name__)

_DATA_RE = re.compile(r'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)</script>', re.S)
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
BLOCK_HINTS = ("captcha", "verify to continue", "tiktok-verify-page", "slide to verify")


def user_detail(text: str) -> dict | None:
    m = _DATA_RE.search(text)
    if not m:
        return None
    try:
        scope = json.loads(m.group(1)).get("__DEFAULT_SCOPE__", {})
    except (ValueError, AttributeError):
        return None
    detail = scope.get("webapp.user-detail") if isinstance(scope, dict) else None
    return detail if isinstance(detail, dict) else None


@register
class TikTok(Platform):
    name = "tiktok"
    display = "TikTok"
    description = "@usernames do TikTok (2-24: a-z 0-9 _ .) - anti-bot forte, confirme manualmente"
    pattern = re.compile(r"[a-z0-9_.]{2,24}")
    default_rate = 0.3
    PROFILE_URL = "https://www.tiktok.com/@{name}"
    BLOCK_COOLDOWN = 180

    def extra_rules(self, name: str) -> bool:
        return not name.endswith(".")

    def profile_url(self, name: str) -> str | None:
        return self.PROFILE_URL.format(name=name)

    def _blocked(self, why: str) -> None:
        log.warning("[tiktok] bloqueio/verificacao (%s) - pausando %ds", why, self.BLOCK_COOLDOWN)
        self.http.limiter.penalize(self.BLOCK_COOLDOWN)

    async def check(self, name: str) -> Status:
        resp = await self.http.request(
            "GET", self.PROFILE_URL.format(name=name), allow_redirects=False,
            headers={"User-Agent": BROWSER_UA, "Accept-Language": "en-US,en;q=0.9"},
        )
        if resp.status in (301, 302, 303, 307, 308):
            self._blocked("redirecionamento")
            return Status.UNKNOWN
        if resp.status not in (200, 404):
            if resp.status in (401, 403):
                self._blocked(f"HTTP {resp.status}")
            return Status.UNKNOWN

        low = resp.text.lower()
        if any(h in low for h in BLOCK_HINTS):
            self._blocked("captcha na pagina")
            return Status.UNKNOWN

        detail = user_detail(resp.text)
        if detail is not None and "statusCode" in detail:
            code = detail.get("statusCode")
            if code == 10202:
                return Status.AVAILABLE
            if code == 0:
                return Status.TAKEN
            return Status.TAKEN  # banido/privado/em revisao: o nome nao esta livre
        if f'"uniqueid":"{name}"' in low:
            return Status.TAKEN
        if "couldn't find this account" in low or '"statuscode":10202' in low:
            return Status.AVAILABLE
        if resp.status == 404:
            return Status.AVAILABLE
        return Status.UNKNOWN
