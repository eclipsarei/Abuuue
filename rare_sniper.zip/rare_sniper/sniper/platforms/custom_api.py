"""Plataformas criadas a partir das APIs customizaveis (apis.json, slots em modo "platform").

Nao precisa editar este arquivo: ligue um slot em modo platform e ele aparece como plataforma.
reload() e chamado pelo menu depois de editar um slot.
"""
from __future__ import annotations

import logging
import re

from sniper.core import custom_api as ca
from sniper.core.platform import REGISTRY, Platform, register
from sniper.core.types import Status

log = logging.getLogger(__name__)
_registered: set[str] = set()


def _make(slot: ca.ApiSlot) -> type[Platform]:
    compiled = re.compile(slot.pattern)
    env = tuple(slot.env_vars())

    class CustomApiPlatform(Platform):
        name = slot.slug
        display = slot.name or slot.slug
        description = f"[API {slot.slot}] " + (slot.description or ca.safe_url(slot.url))
        pattern = compiled
        default_rate = slot.rate
        requires_env = env
        _slot = slot

        async def check(self, name: str) -> Status:
            try:
                method, url, kw = ca.build_request(self._slot, name)
            except ca.ApiError as exc:
                log.error("[%s] %s", self.name, exc)
                return Status.UNKNOWN
            resp = await self.http.request(method, url, **kw)
            return ca.classify(self._slot, resp.status, resp.text)

    CustomApiPlatform.__name__ = f"CustomApi_{slot.slug}"
    return CustomApiPlatform


def reload() -> list[str]:
    """(Re)registra as plataformas dos slots. Retorna os ids registrados."""
    for n in list(_registered):
        REGISTRY.pop(n, None)
    _registered.clear()
    for slot in ca.load_slots():
        if not (slot.enabled and slot.mode == "platform"):
            continue
        errs = ca.validate(slot)
        if errs:
            log.warning("[api %d] ignorada: %s", slot.slot, "; ".join(errs))
            continue
        if slot.slug in REGISTRY:
            log.warning("[api %d] nome '%s' ja usado por outra plataforma - ignorada", slot.slot, slot.slug)
            continue
        register(_make(slot))
        _registered.add(slot.slug)
    return sorted(_registered)


reload()
