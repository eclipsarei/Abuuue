"""Plataforma: Discord (username unico, sem #tag).

O endpoint sem login e o mesmo do cadastro. "taken" cobre nome em uso OU reservado.
Melhoria: 400 com captcha/403 (bloqueio de IP) agora pausam a plataforma em vez de virarem "invalido".
O pacing por cabecalhos x-ratelimit-* e feito pelo nucleo.
"""
from __future__ import annotations

import json
import logging
import re

from sniper.core.platform import Platform, register
from sniper.core.types import Status

log = logging.getLogger(__name__)


@register
class Discord(Platform):
    name = "discord"
    display = "Discord"
    description = "Usernames do Discord (2-32: a-z 0-9 _ .) - 'em uso' inclui reservados"
    pattern = re.compile(r"[a-z0-9_.]{2,32}")
    default_rate = 0.5
    CHECK_URL = "https://discord.com/api/v9/unique-username/username-attempt-unauthed"
    BLOCK_COOLDOWN = 120

    def extra_rules(self, name: str) -> bool:
        return ".." not in name

    def _blocked(self, why: str) -> None:
        log.warning("[discord] bloqueio/captcha (%s) - pausando %ds", why, self.BLOCK_COOLDOWN)
        self.http.limiter.penalize(self.BLOCK_COOLDOWN)

    async def check(self, name: str) -> Status:
        resp = await self.http.request("POST", self.CHECK_URL, json={"username": name})
        if resp.status == 200:
            try:
                return Status.TAKEN if json.loads(resp.text).get("taken") else Status.AVAILABLE
            except (ValueError, AttributeError):
                return Status.UNKNOWN
        if resp.status == 400:
            if "captcha" in resp.text.lower():
                self._blocked("captcha exigido")
                return Status.UNKNOWN
            return Status.INVALID
        if resp.status in (401, 403):
            self._blocked(f"HTTP {resp.status}")
        return Status.UNKNOWN
