"""Plataforma: Instagram (sem login e sem criar conta).

Checagem em 2 etapas, para reduzir falso positivo:
  1) Perfil publico  GET instagram.com/<nome>/
       200 com o nome na pagina -> EM USO
       404                      -> candidato (mas tambem e 404 para conta banida/reservada)
  2) Validacao de cadastro (dry-run, so para os candidatos da etapa 1)
       POST /api/v1/web/accounts/web_create_ajax/attempt/  - o mesmo endpoint que o
       formulario de cadastro do site usa para validar o username; nada e criado.

O Instagram bloqueia rapido (429, redirecionamento para login, "aguarde alguns minutos").
Por isso a taxa padrao e baixa (0.2 req/s) e, ao detectar bloqueio, esta plataforma pausa
sozinha. Endpoints NAO oficiais: podem mudar. Sempre confirme o nome no app antes de contar com ele.
"""
from __future__ import annotations

import json
import logging
import re
import secrets

from sniper.core.platform import Platform, register
from sniper.core.types import RetriesExhausted, Status  # noqa: F401

log = logging.getLogger(__name__)

IG_APP_ID = "936619743392459"  # app id publico do site web do Instagram
SIGNUP_PAGE = "https://www.instagram.com/accounts/emailsignup/"
ATTEMPT_URL = "https://www.instagram.com/api/v1/web/accounts/web_create_ajax/attempt/"
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
BLOCK_HINTS = ("please wait a few minutes", "checkpoint_required", "login_required",
               "feedback_required", "rate_limit", "spam")


@register
class Instagram(Platform):
    name = "instagram"
    display = "Instagram"
    description = "@usernames do Instagram (1-30: a-z 0-9 _ .) - bloqueia rápido, taxa baixa"
    pattern = re.compile(r"[a-z0-9_.]{1,30}")
    default_rate = 0.2
    PROFILE_URL = "https://www.instagram.com/{name}/"
    BLOCK_COOLDOWN = 180  # segundos de pausa ao detectar bloqueio

    def __init__(self, http):
        super().__init__(http)
        self._csrf: str | None = None

    # ------------------------------------------------------------ regras
    def extra_rules(self, name: str) -> bool:
        return not name.startswith(".") and not name.endswith(".") and ".." not in name

    def profile_url(self, name: str) -> str | None:
        return self.PROFILE_URL.format(name=name)

    # ----------------------------------------------------------- helpers
    @staticmethod
    def _page_headers() -> dict[str, str]:
        return {"User-Agent": BROWSER_UA, "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9"}

    def _ajax_headers(self) -> dict[str, str]:
        return {"User-Agent": BROWSER_UA, "Accept": "*/*", "Accept-Language": "en-US,en;q=0.9",
                "X-CSRFToken": self._csrf or "", "X-Requested-With": "XMLHttpRequest",
                "X-IG-App-ID": IG_APP_ID, "Referer": SIGNUP_PAGE}

    def _csrf_from_jar(self) -> str | None:
        try:
            from yarl import URL
            cookies = self.http.session.cookie_jar.filter_cookies(URL("https://www.instagram.com/"))
            morsel = cookies.get("csrftoken")
            return morsel.value if morsel else None
        except Exception:
            return None

    def _blocked(self, why: str) -> None:
        log.warning("[instagram] bloqueio detectado (%s) - pausando %ds", why, self.BLOCK_COOLDOWN)
        self.http.limiter.penalize(self.BLOCK_COOLDOWN)

    async def setup(self) -> None:
        await self._refresh_csrf()

    async def _refresh_csrf(self) -> bool:
        """Pega o csrftoken da pagina publica de cadastro (cookie ou HTML)."""
        resp = None
        try:
            resp = await self.http.request("GET", SIGNUP_PAGE, headers=self._page_headers())
        except RetriesExhausted:
            pass
        token = self._csrf_from_jar()
        if not token and resp is not None and resp.status == 200:
            m = re.search(r'"csrf_token"\s*:\s*"([^"]+)"', resp.text)
            token = m.group(1) if m else None
        self._csrf = token
        if not token:
            log.warning("[instagram] sem csrftoken - a validacao de cadastro (etapa 2) esta indisponivel; "
                        "os resultados dependem so do perfil 404 (menos confiavel)")
        return bool(token)

    # ------------------------------------------------------------- etapa 2
    async def _signup_check(self, name: str) -> Status | None:
        """TAKEN / INVALID / AVAILABLE segundo o cadastro, ou None se inconclusivo."""
        if not self._csrf and not await self._refresh_csrf():
            return None
        data = {"email": f"{secrets.token_hex(6)}@example.com", "username": name,
                "first_name": "", "opt_into_one_tap": "false"}
        resp = None
        for attempt in range(2):
            resp = await self.http.request("POST", ATTEMPT_URL, data=data, headers=self._ajax_headers())
            if resp.status == 403 and attempt == 0:  # csrf vencido: renova e tenta de novo
                await self._refresh_csrf()
                continue
            break
        assert resp is not None
        if resp.status != 200:
            if resp.status in (401, 403):
                self._blocked(f"HTTP {resp.status}")
            return None
        try:
            payload = json.loads(resp.text)
        except ValueError:
            return None
        if not isinstance(payload, dict):
            return None
        errors = payload.get("errors")
        errors = errors if isinstance(errors, dict) else {}
        user_errors = errors.get("username")
        if user_errors:
            blob = json.dumps(user_errors).lower()
            return Status.TAKEN if ("taken" in blob or "held" in blob or "isn't available" in blob
                                    or "isn\\u2019t available" in blob) else Status.INVALID
        text = resp.text.lower()
        if any(h in text for h in BLOCK_HINTS) or (payload.get("status") == "fail" and not errors):
            self._blocked("resposta de limite/checkpoint")
            return None
        if errors or "dryrun_passed" in payload or payload.get("status") == "ok":
            return Status.AVAILABLE  # o username nao foi recusado pelo cadastro
        return None

    # ------------------------------------------------------------ check()
    async def check(self, name: str) -> Status:
        resp = await self.http.request(
            "GET", self.PROFILE_URL.format(name=name),
            headers=self._page_headers(), allow_redirects=False,
        )
        if resp.status == 200:
            low = resp.text.lower()
            if f"@{name}" in low or f"instagram.com/{name}" in low:
                return Status.TAKEN
            return Status.UNKNOWN  # pagina generica (muro de login) - nao prova nada
        if resp.status in (301, 302, 303, 307, 308):
            if "login" in resp.headers.get("location", "").lower():
                self._blocked("redirecionado para login")
            return Status.UNKNOWN
        if resp.status in (401, 403):
            self._blocked(f"HTTP {resp.status}")
            return Status.UNKNOWN
        if resp.status != 404:
            return Status.UNKNOWN

        # 404: pode ser livre OU banida/desativada/reservada -> pergunta ao cadastro
        verdict = await self._signup_check(name)
        if verdict is None:
            log.warning("[instagram] %s: perfil 404 mas a validacao de cadastro falhou - "
                        "evidencia fraca, confirme manualmente", name)
            return Status.AVAILABLE
        return verdict
