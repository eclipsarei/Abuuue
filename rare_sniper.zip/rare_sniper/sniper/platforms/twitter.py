"""Plataforma: X / Twitter (sem login e sem criar conta).

O endpoint publico antigo de disponibilidade foi removido. O caminho sem login que as ferramentas
atuais usam: token de CONVIDADO (POST guest/activate.json com o bearer publico do site) +
consulta GraphQL UserByScreenName.
    perfil existe        -> data.user.result  (User)            -> EM USO
    suspenso/indisponivel-> UserUnavailable                      -> EM USO (nao esta livre)
    sem usuario          -> data sem "user"                      -> candidato LIVRE

Pontos frageis (por isso o plugin se auto-corrige):
  * O queryId da consulta MUDA quando o X publica o site: ele e descoberto no JS do x.com e,
    se der "Query not found", redescoberto (no maximo 1x a cada 10 min).
  * "features" exigidas pela consulta mudam: se o X responder quais faltam, o plugin as adiciona.
  * O token de convidado expira: renovado quando o X recusa (401/403/codigo 239). O plugin NAO
    troca de token para fugir do limite (429): respeita a pausa. Taxa padrao 0.1 req/s (< 150/janela).
Overrides no .env: X_BEARER, X_USERBYSCREENNAME_QID.
"Livre" aqui = nenhum perfil com esse nome. O X tambem reserva nomes (palavras proibidas, contas
apagadas recentemente): confirme no app antes de contar com o nome.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time

from sniper.core.platform import Platform, register
from sniper.core.types import RetriesExhausted, Status

log = logging.getLogger(__name__)

WEB_BEARER = ("AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs"
              "%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA")  # bearer publico do site web
HOME_URL = "https://x.com/"
GUEST_URL = "https://api.x.com/1.1/guest/activate.json"
GQL_URL = "https://api.x.com/graphql/{qid}/UserByScreenName"
FALLBACK_QID = "NimuplG1OB7Fd2btCLdBOw"  # pode estar velho; a descoberta no JS tem prioridade
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
RESERVED_WORDS = ("twitter", "admin")  # o X recusa nomes que contem essas palavras
BASE_FEATURES = {
    "hidden_profile_subscriptions_enabled": False,
    "rweb_tipjar_consumption_enabled": False,
    "responsive_web_graphql_exclude_directive_enabled": True,
    "verified_phone_label_enabled": False,
    "subscriptions_verification_info_is_identity_verified_enabled": False,
    "subscriptions_verification_info_verified_since_enabled": False,
    "highlights_tweets_tab_ui_enabled": False,
    "responsive_web_twitter_article_notes_tab_enabled": False,
    "subscriptions_feature_can_gift_premium": False,
    "creator_subscriptions_tweet_preview_api_enabled": False,
    "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
    "responsive_web_graphql_timeline_navigation_enabled": True,
}


@register
class Twitter(Platform):
    name = "twitter"
    display = "X/Twitter"
    description = "@handles do X/Twitter (4-15: a-z 0-9 _) - token de convidado, taxa baixa"
    pattern = re.compile(r"[a-z0-9_]{4,15}")
    default_rate = 0.1
    BLOCK_COOLDOWN = 120

    def __init__(self, http):
        super().__init__(http)
        self._bearer = os.environ.get("X_BEARER", "").strip() or WEB_BEARER
        self._qid: str | None = os.environ.get("X_USERBYSCREENNAME_QID", "").strip() or None
        self._guest: str | None = None
        self._features = dict(BASE_FEATURES)
        self._last_discovery = 0.0

    # ------------------------------------------------------------- regras
    def extra_rules(self, name: str) -> bool:
        return not any(w in name for w in RESERVED_WORDS)

    def profile_url(self, name: str) -> str | None:
        return f"https://x.com/{name}"

    # ------------------------------------------------------------ helpers
    def _headers(self, guest: bool = True) -> dict[str, str]:
        h = {"User-Agent": BROWSER_UA, "Authorization": f"Bearer {self._bearer}", "Accept": "*/*",
             "Content-Type": "application/json", "X-Twitter-Active-User": "yes",
             "X-Twitter-Client-Language": "en", "Origin": "https://x.com", "Referer": "https://x.com/"}
        if guest and self._guest:
            h["X-Guest-Token"] = self._guest
        return h

    def _blocked(self, why: str) -> None:
        log.warning("[twitter] bloqueio/limite (%s) - pausando %ds", why, self.BLOCK_COOLDOWN)
        self.http.limiter.penalize(self.BLOCK_COOLDOWN)

    async def _static_get(self, url: str) -> str | None:
        """Download de arquivos estaticos do site (sem o limitador da API)."""
        try:
            async with self.http.session.request(
                "GET", url, headers={"User-Agent": BROWSER_UA}, timeout=self.http.timeout
            ) as r:
                return await r.text() if r.status == 200 else None
        except Exception:
            return None

    async def _discover_qid(self) -> bool:
        """Procura o queryId atual de UserByScreenName nos JS do x.com."""
        self._last_discovery = time.monotonic()
        html = await self._static_get(HOME_URL)
        if not html:
            return False
        urls = set(re.findall(r'https://abs\.twimg\.com/responsive-web/client-web[^"\'\s<>]*?\.js', html))
        ordered = sorted(urls, key=lambda u: (0 if "/main." in u else 1 if "/api." in u else 2, u))[:8]
        for url in ordered:
            js = await self._static_get(url)
            if not js:
                continue
            m = re.search(r'queryId:"([A-Za-z0-9_-]+)",operationName:"UserByScreenName"', js)
            if m:
                self._qid = m.group(1)
                log.info("[twitter] queryId descoberto: %s", self._qid)
                return True
        return False

    async def _activate_guest(self) -> bool:
        try:
            resp = await self.http.request("POST", GUEST_URL, headers=self._headers(guest=False))
        except RetriesExhausted:
            return False
        if resp.status == 200:
            try:
                token = json.loads(resp.text).get("guest_token")
            except (ValueError, AttributeError):
                token = None
            if token:
                self._guest = str(token)
                return True
        if resp.status in (401, 403):
            log.warning("[twitter] bearer recusado (HTTP %s) - defina X_BEARER no .env", resp.status)
        return False

    async def setup(self) -> None:
        if not self._qid and not await self._discover_qid():
            log.warning("[twitter] nao achei o queryId no site - usando o padrao (defina "
                        "X_USERBYSCREENNAME_QID se der 'Query not found')")
        if not await self._activate_guest():
            log.warning("[twitter] sem token de convidado por enquanto (nova tentativa a cada checagem)")

    async def _query(self, name: str):
        compact = {"separators": (",", ":")}
        params = {
            "variables": json.dumps({"screen_name": name, "withSafetyModeUserFields": True}, **compact),
            "features": json.dumps(self._features, **compact),
            "fieldToggles": json.dumps({"withAuxiliaryUserLabels": False}, **compact),
        }
        url = GQL_URL.format(qid=self._qid or FALLBACK_QID)
        return await self.http.request("GET", url, params=params, headers=self._headers())

    def _missing_features(self, text: str) -> list[str]:
        m = re.search(r"features cannot be null:\s*([A-Za-z0-9_,\s]+)", text)
        if not m:
            return []
        return [f.strip() for f in m.group(1).split(",") if f.strip() and f.strip() not in self._features]

    def _parse(self, text: str):
        """Status, ou a string "guest" se o token de convidado precisa ser renovado."""
        try:
            payload = json.loads(text)
        except ValueError:
            return Status.UNKNOWN
        if not isinstance(payload, dict):
            return Status.UNKNOWN
        errors = payload.get("errors") or []
        codes = {e.get("code") for e in errors if isinstance(e, dict)}
        if 239 in codes:  # bad guest token
            return "guest"
        if 88 in codes:  # rate limit
            self._blocked("limite de requisicoes")
            return Status.UNKNOWN
        data = payload.get("data")
        if not isinstance(data, dict):
            return Status.UNKNOWN
        user = data.get("user")
        if user:
            typename = (user.get("result") or {}).get("__typename")
            return Status.TAKEN if typename in ("User", "UserUnavailable") else Status.UNKNOWN
        return Status.UNKNOWN if errors else Status.AVAILABLE

    # -------------------------------------------------------------- check
    async def check(self, name: str) -> Status:
        for _ in range(4):
            if not self._guest and not await self._activate_guest():
                self._blocked("sem token de convidado")
                return Status.UNKNOWN
            resp = await self._query(name)
            if resp.status == 200:
                verdict = self._parse(resp.text)
                if verdict == "guest":
                    self._guest = None
                    continue
                return verdict
            if resp.status == 404 and "query not found" in resp.text.lower():
                if time.monotonic() - self._last_discovery > 600 and await self._discover_qid():
                    continue
                log.warning("[twitter] queryId recusado e nao foi possivel redescobrir - "
                            "defina X_USERBYSCREENNAME_QID no .env")
                return Status.UNKNOWN
            if resp.status == 400:
                missing = self._missing_features(resp.text)
                if not missing:
                    return Status.UNKNOWN
                for f in missing:  # o X diz quais "features" faltam: adiciona e repete
                    self._features[f] = False
                log.info("[twitter] features adicionadas: %s", ", ".join(missing))
                continue
            if resp.status in (401, 403):
                self._guest = None
                continue
            return Status.UNKNOWN
        self._blocked("tentativas esgotadas")
        return Status.UNKNOWN
