# sniper by 385 tepes & krypt

Procura usernames raros (dicionário EN/PT + combinações de até N caracteres) em várias
plataformas e **avisa num canal do Discord via webhook** quando acha um disponível.
Não pega a conta sozinho. Cada plataforma é um plugin em arquivo separado.

## Instalação (Kali / WSL)

```bash
sudo apt install python3-venv
python3 -m venv ~/venvs/sniper
source ~/venvs/sniper/bin/activate
pip install -r requirements.txt
cp .env.example .env        # preencha o webhook (veja abaixo)
python3 main.py             # abre o menu
```

Sempre que abrir um terminal novo: `source ~/venvs/sniper/bin/activate`.

## Webhook do Discord (sem bot e sem token de conta)

1. Num servidor seu: Canal → Editar canal → Integrações → Webhooks → Novo webhook → Copiar URL.
2. Cole em `.env` → `DISCORD_WEBHOOK_URL=...`
3. Opcional: `DISCORD_PING_USER_ID=<seu id>` para ser marcado (notificação no celular).
4. Teste: menu → **4) Testar aviso** ou `python3 main.py --test-notify`.

A URL é uma senha: não compartilhe nem suba o `.env` (já está no `.gitignore`).

## Uso

```bash
python3 main.py                                  # menu interativo + painel ao vivo
python3 main.py --run                            # inicia direto com a config salva
python3 main.py --run -p roblox discord --rate 0.5
python3 main.py --run --plain --no-notify        # log simples (tmux/servidor), sem aviso
python3 main.py --download-wordlists             # dicionários completos EN/PT
python3 main.py --list-platforms                 # plugins carregados
python3 main.py --list-apis                      # as 5 APIs customizáveis
python3 main.py --api ip_info 8.8.8.8            # roda uma API customizável
```

Ctrl+C para: o progresso fica em `sniper_state.tsv` e a próxima execução continua de onde parou.
Arquivos gerados: `hits.txt` (achados), `sniper.log`, `sniper_config.json` (menu).

## Estrutura

```
main.py                    ponto de entrada
sniper/
  cli.py  session.py       linha de comando / orquestração de uma execução
  core/
    http.py                rate limiter adaptativo + retry/backoff (429, 5xx, 529)
    platform.py            contrato Platform + registro (@register)
    engine.py              workers, reconfirmação, proteções (cooldown, falso positivo)
    candidates.py          dicionários EN/PT + gerador + download
    notifier.py            aviso via webhook do Discord (agrupa achados)
    custom_api.py          5 APIs customizáveis (apis.json)
    state.py config.py     retomada / configurações
  platforms/               <-- UM ARQUIVO POR PLATAFORMA (auto-descoberta)
    discord.py roblox.py tiktok.py instagram.py twitter.py
    custom_api.py          (cria plataformas a partir do apis.json)
    _template.py           molde para plataformas novas
  ui/                      banner, menu, painel ao vivo
wordlists/                 en.txt, pt.txt
```

## Adicionar uma plataforma (3 passos, sem mexer em mais nada)

1. `cp sniper/platforms/_template.py sniper/platforms/minhaplataforma.py`
2. Edite `name`, `display`, `pattern`, `default_rate` e o `check()`; descomente `@register`.
3. `python3 main.py --list-platforms` — ela já aparece no menu e na CLI.

`self.http.request(...)` dentro do `check()` já faz rate limit, retry e backoff.
Se o plugin tiver erro, ele é ignorado e o erro aparece em **6) Plugins**; os outros seguem normais.
Plataformas que exigem chave de API declaram `requires_env = ("MINHA_CHAVE",)` e só rodam se existir no `.env`.

## Plataformas incluídas

| id | o que checa | taxa padrão |
|----|-------------|-------------|
| `discord` | username único (2-32: a-z 0-9 _ .); "em uso" inclui reservados | 0.5 req/s |
| `roblox` | username (3-20, no máx. 1 `_`) — **100 nomes por requisição** | 0.5 req/s |
| `tiktok` | @username, lê o código de status da página (10202 = não existe) | 0.3 req/s |
| `instagram` | @username (1-30), em 2 etapas (perfil + validação de cadastro) | 0.2 req/s |
| `twitter` | @handle do X (4-15: a-z 0-9 _), token de convidado + GraphQL | 0.1 req/s |

**Melhorias desta versão (a partir de ferramentas existentes):**
- **Roblox em lote:** a API aceita vários nomes por requisição; só quem não aparece no lote é validado
  individualmente. A varredura fica ~100x mais rápida.
- **TikTok:** além de 404/200, lê o JSON da página; conta banida/privada/em revisão conta como *em uso*
  (menos falso positivo), e captcha/verificação pausa a plataforma.
- **Discord:** captcha e bloqueio de IP pausam a plataforma em vez de virarem "inválido".
- **Pausa preventiva (todas):** se a API informa que a cota acabou (`x-ratelimit-*` / `x-rate-limit-*`),
  o motor espera o reset *antes* de levar 429.
- **Proxy do ambiente:** `HTTPS_PROXY`/`HTTP_PROXY` são respeitados. O projeto **não** faz rotação de
  proxies/tokens para fugir de limite: ao tomar 429 ele espera.

**X/Twitter:** o endpoint público antigo foi removido; o plugin usa o token de convidado do site e a consulta
`UserByScreenName`. O `queryId` é descoberto no JS do x.com e redescoberto se girar; as "features" que o X
exigir são adicionadas sozinhas; o token é renovado quando expira. Se mesmo assim der *Query not found*,
defina `X_USERBYSCREENNAME_QID` (e, se o bearer for recusado, `X_BEARER`) no `.env`.
"Livre" = nenhum perfil com esse nome; o X também reserva nomes, então confirme no app.

**Instagram:** etapa 1 olha o perfil público (200 = em uso, 404 = candidato); etapa 2 pergunta ao endpoint de
validação de cadastro do site (nada é criado). Ao detectar bloqueio, pausa 3 min. Varrer 4 letras inteiras não é
viável nessas taxas; use listas pequenas (`--wordlist`) e `--max-len` baixo.

## APIs customizáveis (5 entradas)

Menu **7** ou o arquivo `apis.json`. Cada slot é uma requisição HTTP configurável, sem programar:

- **`lookup`** — consulta manual: informações de um IP, etc. (`--api SLOT VALOR` ou menu). Mostra os campos
  JSON de `show` (ou os 40 primeiros). Com `run_on_start: true`, roda ao iniciar o sniper e loga o resumo (ex.: seu IP).
- **`platform`** — vira uma plataforma do sniper (checa username) segundo as `rules` que você definir.

Já vêm configurados: `meu_ip` (ipify), `ip_info` (ip-api.com: país, cidade, ISP, proxy/hosting), um exemplo de
plataforma (`github_user`, desligado), um exemplo com chave no `.env` (`ipinfo_token`) e um slot livre.

Placeholders na URL, headers e body: `{input}` / `{name}` = valor consultado (na URL vai com URL-encode);
`{env:NOME}` = variável do `.env` (use para chaves; elas nunca vão para o `apis.json`).

```json
{
  "enabled": true, "name": "meusite", "mode": "platform", "method": "GET",
  "url": "https://meusite.com/api/check/{name}",
  "headers": {"Authorization": "Bearer {env:MEUSITE_KEY}"},
  "rate": 1.0, "pattern": "[a-z0-9_]{3,20}",
  "rules": {
    "available": [404, {"json": "taken", "equals": false}],
    "taken":     [200, "already in use"],
    "invalid":   [400]
  }
}
```

Regras: cada uma é um objeto cujas condições valem juntas; basta **uma** da lista bater. Ordem de avaliação:
`invalid` → `taken` → `available`; nada bateu = inconclusivo. Condições: `status` (número ou lista), `contains`,
`not_contains`, `regex`, `json` (caminho `a.b.0.c`) com `equals` ou `exists`. Atalhos: `404` = `{"status":404}`,
`"texto"` = `{"contains":"texto"}`. Slots em modo `platform` e ligados aparecem em `-p`, no menu e no painel.

## Avisos

- Os endpoints de checagem não são APIs oficiais: podem mudar ou exigir captcha.
- Automatizar consultas pode violar os Termos de Serviço das plataformas; use taxas baixas.
- TikTok, Instagram e X têm anti-bot forte e nomes banidos podem parecer livres: confirme manualmente no app.
- 4 letras (a-z) são ~457 mil combinações por plataforma: nas taxas padrão isso leva dias
  (o painel mostra o ETA). Os dicionários rodam primeiro.
